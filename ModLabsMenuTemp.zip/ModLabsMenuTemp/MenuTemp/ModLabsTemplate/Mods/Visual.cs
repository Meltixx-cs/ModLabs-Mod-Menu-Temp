using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

namespace ModLabs.Mods;

/// <summary>Client-side visual examples used by the template.</summary>
public static class Visual
{
    private static bool fullbrightCaptured;
    private static Color oldAmbientColor;
    private static float oldAmbientIntensity;
    private static AmbientMode oldAmbientMode;

    private static bool fogCaptured;
    private static bool oldFog;

    private static bool shadowsCaptured;
    private static ShadowQuality oldShadows;

    private static float nextLeafScan;
    private static readonly Dictionary<Renderer, bool> LeafRenderers = new();

    public static void EnableFullbright()
    {
        if (!fullbrightCaptured)
        {
            oldAmbientColor = RenderSettings.ambientLight;
            oldAmbientIntensity = RenderSettings.ambientIntensity;
            oldAmbientMode = RenderSettings.ambientMode;
            fullbrightCaptured = true;
        }

        ApplyFullbright();
    }

    public static void FullbrightTick() => ApplyFullbright();

    private static void ApplyFullbright()
    {
        RenderSettings.ambientMode = AmbientMode.Flat;
        RenderSettings.ambientLight = Color.white;
        RenderSettings.ambientIntensity = 2.25f;
    }

    public static void DisableFullbright()
    {
        if (!fullbrightCaptured)
            return;

        RenderSettings.ambientMode = oldAmbientMode;
        RenderSettings.ambientLight = oldAmbientColor;
        RenderSettings.ambientIntensity = oldAmbientIntensity;
        fullbrightCaptured = false;
    }

    public static void EnableNoFog()
    {
        if (!fogCaptured)
        {
            oldFog = RenderSettings.fog;
            fogCaptured = true;
        }
        RenderSettings.fog = false;
    }

    public static void NoFogTick() => RenderSettings.fog = false;

    public static void DisableNoFog()
    {
        if (!fogCaptured)
            return;

        RenderSettings.fog = oldFog;
        fogCaptured = false;
    }

    public static void NoLeavesTick()
    {
        if (Time.unscaledTime < nextLeafScan)
            return;

        nextLeafScan = Time.unscaledTime + 1.25f;

        foreach (Renderer renderer in Resources.FindObjectsOfTypeAll<Renderer>())
        {
            if (renderer == null || !renderer.gameObject.scene.IsValid() || IsMenuRenderer(renderer))
                continue;

            if (!LooksLikeLeaves(renderer))
                continue;

            if (!LeafRenderers.ContainsKey(renderer))
                LeafRenderers[renderer] = renderer.enabled;

            renderer.enabled = false;
        }
    }

    public static void DisableNoLeaves()
    {
        foreach (KeyValuePair<Renderer, bool> pair in LeafRenderers)
        {
            if (pair.Key != null)
                pair.Key.enabled = pair.Value;
        }

        LeafRenderers.Clear();
    }

    private static bool LooksLikeLeaves(Renderer renderer)
    {
        static bool Match(string value)
        {
            if (string.IsNullOrEmpty(value))
                return false;

            return value.IndexOf("leaf", StringComparison.OrdinalIgnoreCase) >= 0 ||
                   value.IndexOf("leaves", StringComparison.OrdinalIgnoreCase) >= 0 ||
                   value.IndexOf("foliage", StringComparison.OrdinalIgnoreCase) >= 0 ||
                   value.IndexOf("canopy", StringComparison.OrdinalIgnoreCase) >= 0;
        }

        if (Match(renderer.gameObject.name))
            return true;

        Transform current = renderer.transform.parent;
        for (int i = 0; current != null && i < 4; i++, current = current.parent)
        {
            if (Match(current.name))
                return true;
        }

        if (renderer is MeshRenderer)
        {
            MeshFilter filter = renderer.GetComponent<MeshFilter>();
            if (filter?.sharedMesh != null && Match(filter.sharedMesh.name))
                return true;
        }

        foreach (Material material in renderer.sharedMaterials)
        {
            if (material != null && Match(material.name))
                return true;
            if (material?.mainTexture != null && Match(material.mainTexture.name))
                return true;
        }

        return false;
    }

    private static bool IsMenuRenderer(Renderer renderer)
    {
        try
        {
            return Menu.Main.menu != null && renderer.transform.IsChildOf(Menu.Main.menu.transform);
        }
        catch
        {
            return false;
        }
    }

    public static void EnableNoShadows()
    {
        if (!shadowsCaptured)
        {
            oldShadows = QualitySettings.shadows;
            shadowsCaptured = true;
        }
        QualitySettings.shadows = ShadowQuality.Disable;
    }

    public static void NoShadowsTick() => QualitySettings.shadows = ShadowQuality.Disable;

    public static void DisableNoShadows()
    {
        if (!shadowsCaptured)
            return;

        QualitySettings.shadows = oldShadows;
        shadowsCaptured = false;
    }
}

using System;
using System.Reflection;
using GorillaLocomotion;
using HarmonyLib;
using ModLabs.Menu;
using UnityEngine;
using UnityEngine.XR;

namespace ModLabs.Mods;


public static class Movement
{
    private static FieldInfo maxArmLengthField;
    private static PropertyInfo maxArmLengthProperty;
    private static bool armLengthCaptured;
    private static float originalArmLength;

    private static GameObject teleportPointer;
    private static LineRenderer teleportLine;
    private static Material teleportMaterial;
    private static bool previousTeleportTrigger;

    public static void EnableLongArms()
    {
        TrySetLongArms(captureOriginal: true);
    }

    public static void LongArmsTick()
    {
        // Re-apply in case Gorilla Tag refreshes locomotion values after a room/map change.
        TrySetLongArms(captureOriginal: true);
    }

    public static void DisableLongArms()
    {
        GTPlayer player = GTPlayer.Instance;
        if (player == null || !armLengthCaptured)
            return;

        try
        {
            EnsureArmLengthMember();
            if (maxArmLengthField != null)
                maxArmLengthField.SetValue(player, originalArmLength);
            else if (maxArmLengthProperty?.CanWrite == true)
                maxArmLengthProperty.SetValue(player, originalArmLength);
        }
        catch (Exception exception)
        {
            Debug.LogWarning($"[{Constants.Name}] Could not restore arm length: {exception.Message}");
        }
        finally
        {
            armLengthCaptured = false;
        }
    }

    private static void TrySetLongArms(bool captureOriginal)
    {
        GTPlayer player = GTPlayer.Instance;
        if (player == null)
            return;

        try
        {
            EnsureArmLengthMember();

            if (maxArmLengthField != null)
            {
                if (captureOriginal && !armLengthCaptured && maxArmLengthField.GetValue(player) is float oldValue)
                {
                    originalArmLength = oldValue;
                    armLengthCaptured = true;
                }

                maxArmLengthField.SetValue(player, Config.LongArmsLength);
                return;
            }

            if (maxArmLengthProperty?.CanWrite == true)
            {
                if (captureOriginal && !armLengthCaptured && maxArmLengthProperty.GetValue(player) is float oldValue)
                {
                    originalArmLength = oldValue;
                    armLengthCaptured = true;
                }

                maxArmLengthProperty.SetValue(player, Config.LongArmsLength);
            }
        }
        catch (Exception exception)
        {
            Debug.LogWarning($"[{Constants.Name}] Long Arms could not update maxArmLength: {exception.Message}");
        }
    }

    private static void EnsureArmLengthMember()
    {
        maxArmLengthField ??= AccessTools.Field(typeof(GTPlayer), "maxArmLength");
        maxArmLengthProperty ??= AccessTools.Property(typeof(GTPlayer), "maxArmLength");
    }

    public static void Fly()
    {
        if (ControllerInputPoller.instance == null ||
            !ControllerInputPoller.instance.rightControllerPrimaryButton ||
            GTPlayer.Instance == null ||
            GorillaTagger.Instance?.headCollider == null ||
            GorillaTagger.Instance.rigidbody == null)
            return;

        GTPlayer.Instance.transform.position +=
            GorillaTagger.Instance.headCollider.transform.forward * Time.deltaTime * Config.FlySpeed;

        GorillaTagger.Instance.rigidbody.linearVelocity = Vector3.zero;
    }

    public static void TeleportGun()
    {
        if (ControllerInputPoller.instance == null || GorillaTagger.Instance == null)
        {
            HideTeleportGunVisuals();
            return;
        }

        bool grip = ControllerInputPoller.instance.rightGrab;
        if (!grip)
        {
            previousTeleportTrigger = false;
            HideTeleportGunVisuals();
            return;
        }

        Transform hand = GorillaTagger.Instance.rightHandTransform;
        if (hand == null)
            return;

        EnsureTeleportGunVisuals();

        Vector3 start = hand.position;
        Vector3 direction = hand.forward.normalized;
        Vector3 rayOrigin = start + direction * 0.15f;

        bool didHit = TryTeleportRaycast(rayOrigin, direction, out RaycastHit hit);
        Vector3 end = didHit
            ? hit.point
            : rayOrigin + direction * Config.TeleportGunMaxDistance;

        teleportLine.gameObject.SetActive(true);
        teleportLine.positionCount = 2;
        teleportLine.SetPosition(0, start);
        teleportLine.SetPosition(1, end);
        teleportLine.startWidth = Config.TeleportGunLineWidth;
        teleportLine.endWidth = Config.TeleportGunLineWidth;
        teleportLine.startColor = Config.TeleportGunColor;
        teleportLine.endColor = Config.TeleportGunColor;

        teleportPointer.SetActive(true);
        teleportPointer.transform.position = end;
        teleportPointer.transform.localScale = Vector3.one * Config.TeleportGunPointerSize;

        bool trigger = ControllerInputPoller.TriggerFloat(XRNode.RightHand) > 0.55f;
        if (trigger && !previousTeleportTrigger && didHit && GTPlayer.Instance != null)
        {
            GTPlayer.Instance.TeleportTo(
                end + Vector3.up * 0.75f,
                GTPlayer.Instance.transform.rotation);

            if (GorillaTagger.Instance.rigidbody != null)
                GorillaTagger.Instance.rigidbody.linearVelocity = Vector3.zero;
        }

        previousTeleportTrigger = trigger;
    }

    public static void DisableTeleportGun()
    {
        previousTeleportTrigger = false;

        if (teleportPointer != null)
            UnityEngine.Object.Destroy(teleportPointer);
        if (teleportLine != null)
            UnityEngine.Object.Destroy(teleportLine.gameObject);
        if (teleportMaterial != null)
            UnityEngine.Object.Destroy(teleportMaterial);

        teleportPointer = null;
        teleportLine = null;
        teleportMaterial = null;
    }

    private static bool TryTeleportRaycast(Vector3 origin, Vector3 direction, out RaycastHit hit)
    {
        RaycastHit[] hits = Physics.RaycastAll(
            origin,
            direction,
            Config.TeleportGunMaxDistance,
            ~0,
            QueryTriggerInteraction.Ignore);

        Array.Sort(hits, (a, b) => a.distance.CompareTo(b.distance));

        foreach (RaycastHit candidate in hits)
        {
            Collider collider = candidate.collider;
            if (collider == null)
                continue;

            Transform transform = collider.transform;

            // Ignore the local gorilla and the ModLabs menu so the gun reaches the world.
            if (GorillaTagger.Instance != null && transform.IsChildOf(GorillaTagger.Instance.transform))
                continue;
            if (Main.menu != null && transform.IsChildOf(Main.menu.transform))
                continue;

            hit = candidate;
            return true;
        }

        hit = default;
        return false;
    }

    private static void EnsureTeleportGunVisuals()
    {
        if (teleportMaterial == null)
        {
            Shader shader = Shader.Find("GUI/Text Shader") ??
                            Shader.Find("Unlit/Color") ??
                            Shader.Find("Standard");

            teleportMaterial = new Material(shader)
            {
                color = Config.TeleportGunColor,
                name = "ML_TeleportGunMaterial"
            };
        }

        if (teleportLine == null)
        {
            GameObject lineObject = new("ML_TeleportGunLine");
            teleportLine = lineObject.AddComponent<LineRenderer>();
            teleportLine.useWorldSpace = true;
            teleportLine.numCapVertices = 6;
            teleportLine.numCornerVertices = 6;
            teleportLine.sharedMaterial = teleportMaterial;
        }

        if (teleportPointer == null)
        {
            teleportPointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            teleportPointer.name = "ML_TeleportGunDot";
            Collider collider = teleportPointer.GetComponent<Collider>();
            if (collider != null)
                UnityEngine.Object.Destroy(collider);

            Renderer renderer = teleportPointer.GetComponent<Renderer>();
            if (renderer != null)
                renderer.sharedMaterial = teleportMaterial;
        }
    }

    private static void HideTeleportGunVisuals()
    {
        if (teleportLine != null)
            teleportLine.gameObject.SetActive(false);
        if (teleportPointer != null)
            teleportPointer.SetActive(false);
    }
}

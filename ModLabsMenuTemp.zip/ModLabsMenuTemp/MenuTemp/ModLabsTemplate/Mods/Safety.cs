using BepInEx;
using ModLabs.Menu;
using ModLabs.Notifications;
using UnityEngine;
using UnityEngine.XR;

namespace ModLabs.Mods;

/// <summary>
/// Simple local safety / convenience examples for the community template.
/// These do not patch reporting, anti-cheat, telemetry, or networking internals.
/// </summary>
public static class Safety
{
    public static bool JoinAlertsEnabled { get; private set; }
    public static bool LeaveAlertsEnabled { get; private set; }

    private static float panicDelay;
    private static float clearDelay;

    public static void SetJoinAlerts(bool enabled) => JoinAlertsEnabled = enabled;
    public static void SetLeaveAlerts(bool enabled) => LeaveAlertsEnabled = enabled;

    public static void SetHideNotifications(bool enabled)
    {
        Settings.disableNotifications = enabled;
        if (enabled)
            NotifiLib.ClearAllNotificationsSafe();
    }

    /// <summary>PC: End. VR: both grips + both triggers.</summary>
    public static void PanicDisconnect()
    {
        if (Time.time <= panicDelay)
            return;

        bool pc = false;
        try
        {
            pc = UnityInput.Current.GetKey(KeyCode.End);
        }
        catch { }

        bool vr = ControllerInputPoller.instance != null &&
                  ControllerInputPoller.instance.leftGrab &&
                  ControllerInputPoller.instance.rightGrab &&
                  ControllerInputPoller.TriggerFloat(XRNode.LeftHand) > 0.8f &&
                  ControllerInputPoller.TriggerFloat(XRNode.RightHand) > 0.8f;

        if (!pc && !vr)
            return;

        panicDelay = Time.time + 1f;
        if (NetworkSystem.Instance != null && NetworkSystem.Instance.InRoom)
            NetworkSystem.Instance.ReturnToSinglePlayer();
    }

    /// <summary>Example local convenience toggle that periodically clears template popups.</summary>
    public static void AutoClearNotifications()
    {
        if (Time.unscaledTime < clearDelay)
            return;

        clearDelay = Time.unscaledTime + 2f;
        NotifiLib.ClearAllNotificationsSafe();
    }

    /// <summary>Safe no-op slot intentionally left for community authors.</summary>
    public static void Placeholder() { }
}

# ModLabs Community Menu Template

This project contains modifications based on a public Gorilla Tag menu template distributed under the Apache License 2.0. The upstream source credited @goldentrophy and @zlothyy.

ModLabs-specific work in this fork includes the custom ModLabs prefab integration, centralized `Config.cs`, automatic category registry, dynamic Enabled Mods page, title gradient animation, embedded transparent title icon, configurable blue/white theme, page navigation, desktop/VR interaction fixes, runtime TMP styling, even mesh-outline system, and open/close presentation.

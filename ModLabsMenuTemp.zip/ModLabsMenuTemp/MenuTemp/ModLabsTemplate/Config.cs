using GorillaLocomotion;
using ModLabs.Classes;
using ModLabs.Menu;
using ModLabs.Mods;
using TMPro;
using UnityEngine;

namespace ModLabs;


/// This is the main file feature developers should edit.
///
/// Sections:
///   1. Branding
///   2. Theme colors
///   3. Text/font style
///   4. Animated title gradient
///   5. Menu layout/behaviour defaults
///   6. Categories + mods
///   7. Settings-page buttons
///
/// You should not need to edit Menu/Main.cs just to recolor the menu, rename it,
/// add a category, or add/remove a normal mod button.

public static class Config
{
    
    // 1) BRANDING
    

    public const string MenuName = "ModLabs Temp";
    public const string DeveloperCredit = "-Meltixx"; // Do not remove credits or else your a skid

   
    public const bool ShowTitleIcon = true; // Put false if you dont want a icon but it will help us out if you leave it on 
    public const string TitleIconResourceName = "modlabs_title_icon.png"; // If you wanna change this put your image into assets and change the script "modlabs_title_icon.png" to your name of the image

  
    public static readonly Vector3 TitleIconLocalPosition = new(8.7f, 0f, 0.03f);
    public static readonly Vector3 TitleIconLocalScale = new(4.2f, 4.2f, 1f);

   
    // 2) THEME COLORS
  

    // Main menu shell
    public static readonly Color MainColor = new Color32(22, 74, 136, 255);

    // Normal category/mod buttons
    public static readonly Color ButtonColor = new Color32(43, 105, 181, 255);

    // Toggle enabled state + click flash
    public static readonly Color ButtonEnabledColor = new Color32(5, 28, 58, 255);

    // Requested clean white outline on the whole template
    public static readonly Color OutlineColor = Color.white;

    // Normal label color
    public static readonly Color TextColor = Color.white;

    // TextMeshPro outline around labels
    public static readonly Color TextOutlineColor = Color.black;
    public const float TextOutlineWidth = 0.10f;

    
    public static readonly Color PageArrowColor = Color.white;

   
    public static readonly Color VoidColor = new Color32(2, 7, 18, 255);

   
    // 3) TEXT / FONT STYLE
 


    public static readonly string[] FontNameHints =
    {
        "Roboto-Regular",
        "Roboto Regular",
        "Roboto-Medium",
        "Roboto Medium",
        "Roboto",
        "Gotham",
        "Arial",
        "LiberationSans",
    };

    // Reference-menu style: smooth regular-weight text instead of chunky bold.
    public const FontStyles TextFontStyle = FontStyles.Normal;
    public const FontWeight TextFontWeight = FontWeight.Light;

    public const float TitleFontSize = 22f;
    public const float ButtonFontSize = 18.5f;
    public const float ButtonFontSizeLong = 16.5f;
    public const float ButtonFontSizeVeryLong = 14.5f;
    public const float CreditFontSize = 12f;
    public const float ArrowFontSize = 7.0f;

    // Used only by the legacy notification helper.
    public static readonly Font LegacyNotificationFont =
        Resources.GetBuiltinResource(typeof(Font), "Arial.ttf") as Font;

    public const float TitleCharacterSpacing = 0.35f;
    public const float ButtonCharacterSpacing = 0f;

    
    // 4) ANIMATED TITLE GRADIENT
   

    public const bool AnimatedTitleGradient = true;

    // Higher = gradient moves faster across the title.
    public const float TitleGradientSpeed = 0.48f;

    // How often the rich-text colors are refreshed. 20 Hz is visually smooth
    // while avoiding needless per-frame string/material work.
    public const float TitleGradientRefreshRate = 20f;

    // Edit/add/remove colors freely. The animation loops through the array.
    public static readonly Color[] TitleGradientColors =
    {
        new Color32(38, 224, 255, 255), // cyan
        new Color32(255, 255, 255, 255), // white
        new Color32(38, 224, 255, 255), // cyan
    };

    
    // 5) MENU LAYOUT DEFAULTS
    

    public const bool DefaultRightHanded = false; // put true if you want it on your left hand by default
    public const bool DefaultHoldToOpen = true;
    public const bool DefaultAnimateMenu = true;
    public const bool DefaultMenuSounds = true;
    public const bool DefaultButtonHaptics = true;
    public const KeyCode DefaultKeyboardButton = KeyCode.Q;

    public static readonly Vector3 DefaultMenuScale = new(0.135f, 0.135f, 0.135f);
    public const float DefaultDesktopDistance = 0.50f;

    public const int ButtonsPerPage = 5;
    public const float ButtonRowSpacing = 0.34f;
    public const float OpenAnimationSpeed = 4.5f;
    public const float CloseAnimationSpeed = 5.2f;
    public const float ClickFlashSeconds = 0.09f;

    // Movement mod adjusting 
    public const float LongArmsLength = 4.0f;
    public const float FlySpeed = 15f;
    public const float TeleportGunMaxDistance = 250f;
    public const float TeleportGunLineWidth = 0.018f;
    public const float TeleportGunPointerSize = 0.09f;
    public static readonly Color TeleportGunColor = Color.white;

    // Scale
    public const float ModelWidthMultiplier = 0.72f;
    public const float DesktopRollCorrection = -90f;

    
    public const float OutlineWorldThickness = 0.0023f;
    public const float OutlineDepthScale = 0.94f;

   
    // 6) CATEGORIES + MODS
   
    //
    // HOW TO ADD A MOD:

    // Go to the desired location you wanna add a mod to like Movement.cs if you wanna add speedboost you will add the script to it like this format 


    //   public static void DisableLongArms()
     //    {
     //      Your mod code goes in here 
     //     }
     //   }

    // Example one-click action:
    // ButtonInfo.Action("Placeholder", Placeholder.RunOnce, "What it does."),
    //
    // HOW TO ADD A CATEGORY:
    // Copy this format below and paste it below any category

    public static readonly MenuCategoryConfig[] CommunityCategories =
    {
        new(
            name: "Movement Mods",
            showOnHome: true,
            buttons: new ButtonInfo[]
            {
                ButtonInfo.Toggle(
                    "Long Arms",
                    tick: Movement.LongArmsTick,
                    onEnable: Movement.EnableLongArms,
                    onDisable: Movement.DisableLongArms,
                    tip: "Extends your local arm reach while enabled."),

                ButtonInfo.Toggle(
                    "Fly (A)",
                    tick: Movement.Fly,
                    tip: "Hold A while enabled to fly forward."),

                ButtonInfo.Toggle(
                    "Teleport Gun",
                    tick: Movement.TeleportGun,
                    onDisable: Movement.DisableTeleportGun,
                    tip: "Hold right grip to aim. Press right trigger to teleport to the white dot."),
            }),

        new(
            name: "Safety Mods",
            showOnHome: true,
            buttons: new ButtonInfo[]
            {
                ButtonInfo.Toggle(
                    "Panic Disconnect Hotkey",
                    tick: Safety.PanicDisconnect,
                    tip: "PC: End key. VR: both grips + both triggers to immediately leave."),
            }),




        new(
            name: "Visual Mods",
            showOnHome: true,
            buttons: new ButtonInfo[]
            {
                ButtonInfo.Toggle(
                    "Fullbright",
                    tick: Visual.FullbrightTick,
                    onEnable: Visual.EnableFullbright,
                    onDisable: Visual.DisableFullbright,
                    tip: "Brightens ambient lighting on the local client."),

                ButtonInfo.Toggle(
                    "No Fog",
                    tick: Visual.NoFogTick,
                    onEnable: Visual.EnableNoFog,
                    onDisable: Visual.DisableNoFog,
                    tip: "Disables Unity fog on the local client."),

                ButtonInfo.Toggle(
                    "No Leaves",
                    tick: Visual.NoLeavesTick,
                    onDisable: Visual.DisableNoLeaves,
                    tip: "Hides renderers with leaf/leaves in their object name."),

                ButtonInfo.Toggle(
                    "No Shadows",
                    tick: Visual.NoShadowsTick,
                    onEnable: Visual.EnableNoShadows,
                    onDisable: Visual.DisableNoShadows,
                    tip: "Disables local realtime shadows."),
            }),

            new(
            name: "PlaceHolder",
            showOnHome: true,
            buttons: new ButtonInfo[]
            {

            }),


    };

    // Enabled Mods is generated automatically from every toggle above that is on.
    public const string EnabledModsCategoryName = "Enabled Mods";

    
    // 7) SETTINGS PAGE BUTTONS
    

    public static readonly ButtonInfo[] SettingsButtons =
    {
        ButtonInfo.Toggle(
            "Hide Notifications",
            onEnable: () => Safety.SetHideNotifications(true),
            onDisable: () => Safety.SetHideNotifications(false),
            tip: "Hides ModLabs notification popups."),

        ButtonInfo.Toggle(
            "Leave Alerts",
            onEnable: () => Safety.SetLeaveAlerts(true),
            onDisable: () => Safety.SetLeaveAlerts(false),
            tip: "Shows a notification when a player leaves."),

        ButtonInfo.Toggle(
            "Join Alerts",
            onEnable: () => Safety.SetJoinAlerts(true),
            onDisable: () => Safety.SetJoinAlerts(false),
            tip: "Shows a notification when a player joins."),

        ButtonInfo.Toggle(
            "Right Hand",
            onEnable: () => Settings.rightHanded = true,
            onDisable: () => Settings.rightHanded = false,
            enabledByDefault: DefaultRightHanded,
            tip: "Moves the VR menu to your right hand."),

        ButtonInfo.Toggle(
            "Hold To Open",
            onEnable: () => Settings.holdToOpen = true,
            onDisable: () => Settings.holdToOpen = false,
            enabledByDefault: DefaultHoldToOpen,
            tip: "When on, hold the menu button/Q. When off, press once to toggle."),

        ButtonInfo.Toggle(
            "Menu Animations",
            onEnable: () => Settings.animateMenu = true,
            onDisable: () => Settings.animateMenu = false,
            enabledByDefault: DefaultAnimateMenu,
            tip: "Toggles the smooth open/close animation."),

        ButtonInfo.Toggle(
            "Menu Sounds",
            onEnable: () => Settings.menuSounds = true,
            onDisable: () => Settings.menuSounds = false,
            enabledByDefault: DefaultMenuSounds,
            tip: "Toggles click/open/close sounds."),

        ButtonInfo.Toggle(
            "Button Haptics",
            onEnable: () => Settings.buttonHaptics = true,
            onDisable: () => Settings.buttonHaptics = false,
            enabledByDefault: DefaultButtonHaptics,
            tip: "Toggles vibration when pressing menu buttons in VR."),
    };
}

/// <summary>
/// One editable community category. Add it once in Config.CommunityCategories.
/// </summary>
public sealed class MenuCategoryConfig
{
    public string Name { get; }
    public bool ShowOnHome { get; }
    public ButtonInfo[] Buttons { get; }

    public MenuCategoryConfig(string name, bool showOnHome, ButtonInfo[] buttons)
    {
        Name = string.IsNullOrWhiteSpace(name) ? "Placeholder" : name;
        ShowOnHome = showOnHome;
        Buttons = buttons ?? System.Array.Empty<ButtonInfo>();
    }
}

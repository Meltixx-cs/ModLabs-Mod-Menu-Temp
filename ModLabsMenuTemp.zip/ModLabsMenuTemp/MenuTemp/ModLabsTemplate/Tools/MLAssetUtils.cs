using System;
using System.IO;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using UnityEngine;

namespace ModLabs.Tools;

/// <summary>
/// Embedded AssetBundle loader.
///
/// This intentionally follows the original template's working LoadFromStream approach.
/// The bundle version is logged for troubleshooting, but this loader does not
/// silently replace the user's prefab with a generated fallback model.
/// </summary>
public static class MLAssetUtils
{
    private const string ResourcePrefix = "ModLabs";

    public static string LastError { get; private set; } = string.Empty;
    public static string LastBundleUnityVersion { get; private set; } = string.Empty;

    public static Stream OpenResource(string assetName) =>
        Assembly.GetExecutingAssembly().GetManifestResourceStream($"{ResourcePrefix}.Assets.{assetName}");

    public static Texture2D LoadTexture(string assetName)
    {
        LastError = string.Empty;
        Stream stream = OpenResource(assetName);
        if (stream == null)
        {
            LastError = $"Embedded texture was not found: {assetName}";
            Debug.LogError($"[{Constants.Name}] {LastError}");
            return null;
        }

        try
        {
            using (stream)
            using (MemoryStream memory = new())
            {
                stream.CopyTo(memory);
                Texture2D texture = new(2, 2, TextureFormat.RGBA32, false)
                {
                    name = Path.GetFileNameWithoutExtension(assetName),
                    wrapMode = TextureWrapMode.Clamp,
                    filterMode = FilterMode.Bilinear,
                };

                if (!ImageConversion.LoadImage(texture, memory.ToArray(), false))
                {
                    UnityEngine.Object.Destroy(texture);
                    LastError = $"Unity could not decode embedded texture '{assetName}'.";
                    Debug.LogError($"[{Constants.Name}] {LastError}");
                    return null;
                }

                return texture;
            }
        }
        catch (Exception exception)
        {
            LastError = $"Failed to load embedded texture '{assetName}': {exception.Message}";
            Debug.LogError($"[{Constants.Name}] {LastError}");
            return null;
        }
    }

    public static AssetBundle LoadAssetBundle(string bundleName)
    {
        LastError = string.Empty;
        LastBundleUnityVersion = string.Empty;

        Stream stream = OpenResource(bundleName);
        if (stream == null)
        {
            LastError = $"Embedded asset was not found: {bundleName}";
            Debug.LogError($"[{Constants.Name}] {LastError}");
            return null;
        }

        try
        {
            // Read only a small header for diagnostics, then rewind before Unity reads the bundle.
            if (stream.CanSeek)
            {
                byte[] header = new byte[Math.Min(256, (int)stream.Length)];
                int read = stream.Read(header, 0, header.Length);
                stream.Position = 0;
                LastBundleUnityVersion = FindUnityVersion(header, read);

                if (!string.IsNullOrWhiteSpace(LastBundleUnityVersion))
                {
                    Debug.Log($"[{Constants.Name}] Loading '{bundleName}' built with Unity {LastBundleUnityVersion}; game reports {Application.unityVersion}.");
                }
            }

            // Same fundamental loading path as the original working the original template.
            AssetBundle bundle = AssetBundle.LoadFromStream(stream);
            if (bundle == null)
            {
                LastError = $"Unity returned null while loading embedded bundle '{bundleName}'.";
                Debug.LogError($"[{Constants.Name}] {LastError}");
            }

            return bundle;
        }
        catch (Exception exception)
        {
            LastError = $"Failed to load '{bundleName}': {exception.Message}";
            Debug.LogError($"[{Constants.Name}] {LastError}");
            return null;
        }
    }

    private static string FindUnityVersion(byte[] data, int count)
    {
        if (data == null || count <= 0)
            return string.Empty;

        string header = Encoding.ASCII.GetString(data, 0, Math.Min(count, data.Length));
        Match match = Regex.Match(header, @"\b\d{4}\.\d+\.\d+(?:[abfp]\d+)?\b");
        return match.Success ? match.Value : string.Empty;
    }
}

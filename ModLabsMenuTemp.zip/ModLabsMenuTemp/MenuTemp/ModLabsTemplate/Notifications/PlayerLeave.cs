using HarmonyLib;
using ModLabs.Mods;
using ModLabs.Notifications;
using Photon.Pun;
using Photon.Realtime;
using UnityEngine;

namespace ModLabs.Patches;

[HarmonyPatch(typeof(MonoBehaviourPunCallbacks), "OnPlayerLeftRoom")]
public class LeavePatch : MonoBehaviour
{
    private static Player previousPlayer;

    private static void Prefix(Player otherPlayer)
    {
        if (!Safety.LeaveAlertsEnabled ||
            otherPlayer == null ||
            otherPlayer == PhotonNetwork.LocalPlayer ||
            otherPlayer == previousPlayer)
            return;

        NotifiLib.SendNotification(
            "<color=#6BAEFF>[LEAVE]</color> <color=white>" + otherPlayer.NickName + "</color>");

        previousPlayer = otherPlayer;
    }
}

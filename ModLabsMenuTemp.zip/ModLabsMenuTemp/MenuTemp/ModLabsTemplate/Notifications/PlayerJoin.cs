using HarmonyLib;
using ModLabs.Mods;
using ModLabs.Notifications;
using Photon.Pun;
using Photon.Realtime;
using UnityEngine;

namespace ModLabs.Patches;

[HarmonyPatch(typeof(MonoBehaviourPunCallbacks), "OnPlayerEnteredRoom")]
public class JoinPatch : MonoBehaviour
{
    private static Player previousPlayer;

    private static void Prefix(Player newPlayer)
    {
        if (!Safety.JoinAlertsEnabled || newPlayer == null || newPlayer == previousPlayer)
            return;

        NotifiLib.SendNotification(
            "<color=#6BAEFF>[JOIN]</color> <color=white>" + newPlayer.NickName + "</color>");

        previousPlayer = newPlayer;
    }
}

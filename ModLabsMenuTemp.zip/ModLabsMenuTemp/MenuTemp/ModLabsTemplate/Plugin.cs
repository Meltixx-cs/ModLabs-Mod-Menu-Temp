using System.ComponentModel;
using BepInEx;
using ModLabs.Classes;
using ModLabs.Patches;

namespace ModLabs;

[Description(Constants.Description)]
[BepInPlugin(Constants.Guid, Constants.Name, Constants.Version)]
public sealed class Plugin : BaseUnityPlugin
{
    private void Awake()
    {
        Preferences.Load();
        gameObject.AddComponent<CoroutineManager>();

        GorillaTagger.OnPlayerSpawned(OnPlayerSpawned);
    }

    private void OnPlayerSpawned()
    {
        PatchHandler.PatchAll();
        Preferences.ApplyButtonStates();
    }

    private void OnApplicationQuit() => Preferences.Save();
}

using UnityEngine;

namespace ModLabs.Classes;


public sealed class MenuAudio : MonoBehaviour
{
    private AudioSource source;
    private AudioClip clickClip;
    private AudioClip openClip;
    private AudioClip closeClip;

    private const int SampleRate = 44100;

    private void Awake()
    {
        source = gameObject.AddComponent<AudioSource>();
        source.playOnAwake = false;
        source.spatialBlend = 0.15f;
        source.volume = 0.7f;

        clickClip = BuildWoodTap();
        openClip = BuildSweep("ML_Open", 0.24f, 220f, 760f);
        closeClip = BuildSweep("ML_Close", 0.20f, 650f, 170f);
    }

    public void PlayClick(float volume = 0.65f)
    {
        if (clickClip != null)
            source.PlayOneShot(clickClip, volume);
    }

    public void PlayOpen()
    {
        if (openClip != null)
            source.PlayOneShot(openClip, 0.55f);
    }

    public void PlayClose()
    {
        if (closeClip != null)
            source.PlayOneShot(closeClip, 0.52f);
    }

    private static AudioClip BuildWoodTap()
    {
        const float duration = 0.085f;
        int count = Mathf.CeilToInt(duration * SampleRate);
        float[] samples = new float[count];

        for (int i = 0; i < count; i++)
        {
            float t = i / (float)SampleRate;
            float decay = Mathf.Exp(-t * 48f);

            float body = Mathf.Sin(2f * Mathf.PI * 230f * t) * 0.65f;
            float knock = Mathf.Sin(2f * Mathf.PI * 410f * t) * 0.28f;
            float grain = (Mathf.PerlinNoise(i * 0.173f, 0.37f) * 2f - 1f) * 0.16f;

            samples[i] = (body + knock + grain) * decay;
        }

        AudioClip clip = AudioClip.Create("ML_WoodTap", count, 1, SampleRate, false);
        clip.SetData(samples, 0);
        return clip;
    }

    private static AudioClip BuildSweep(string name, float duration, float startFrequency, float endFrequency)
    {
        int count = Mathf.CeilToInt(duration * SampleRate);
        float[] samples = new float[count];
        float phase = 0f;

        for (int i = 0; i < count; i++)
        {
            float normalized = i / (float)(count - 1);
            float frequency = Mathf.Lerp(startFrequency, endFrequency, Smooth(normalized));
            phase += 2f * Mathf.PI * frequency / SampleRate;

            float attack = Mathf.Clamp01(normalized / 0.08f);
            float release = Mathf.Clamp01((1f - normalized) / 0.22f);
            float envelope = attack * release;

            float primary = Mathf.Sin(phase) * 0.42f;
            float shimmer = Mathf.Sin(phase * 2.01f) * 0.12f;
            samples[i] = (primary + shimmer) * envelope;
        }

        AudioClip clip = AudioClip.Create(name, count, 1, SampleRate, false);
        clip.SetData(samples, 0);
        return clip;
    }

    private static float Smooth(float value) => value * value * (3f - 2f * value);
}

namespace ModLabs.Classes;

public sealed class ButtonCategory
{
    public string name = "Placeholder";
    public ButtonInfo[] buttons = [];
}

using UnityEngine;

namespace ModLabs.Classes;

public class CoroutineManager : MonoBehaviour
{
    public static CoroutineManager Instance;

    private void Awake() => Instance = this;
}
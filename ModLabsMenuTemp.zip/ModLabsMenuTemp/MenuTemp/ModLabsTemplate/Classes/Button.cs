using UnityEngine;
using static ModLabs.Menu.Main;

namespace ModLabs.Classes;


public sealed class Button : MonoBehaviour
{
    public static float buttonCooldown;

    public ButtonInfo relatedButton;
    public GameObject visualTarget;

    public void OnTriggerEnter(Collider collider)
    {
        if (Time.unscaledTime <= buttonCooldown || menu == null || relatedButton == null)
            return;

        if (!TryGetReferenceHand(collider, out bool pressingRightHand))
            return;

        buttonCooldown = Time.unscaledTime + 0.16f;
        QueueButtonPress(relatedButton, visualTarget ?? transform.parent?.gameObject ?? gameObject, pressingRightHand);
    }

    public void PressDesktop()
    {
        if (Time.unscaledTime <= buttonCooldown || menu == null || relatedButton == null)
            return;

        buttonCooldown = Time.unscaledTime + 0.16f;
        QueueButtonPress(relatedButton, visualTarget ?? transform.parent?.gameObject ?? gameObject, null);
    }
}

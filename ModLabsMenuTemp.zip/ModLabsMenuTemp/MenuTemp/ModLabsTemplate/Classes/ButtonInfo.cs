using System;

namespace ModLabs.Classes;

public enum ButtonMode
{
    Toggle,
    Action,
    Incremental,
}


public sealed class ButtonInfo
{
    public string buttonText = "Placeholder";
    public string toolTip = "Placeholder";

    // Toggle lifecycle:
    // method runs every game tick while the toggle is enabled.
    // enableMethod / disableMethod run once when the state changes.
    public Action method;
    public Action enableMethod;
    public Action disableMethod;

    // Incremental buttons are kept for community extensions.
    public Action<bool> incrementMethod;

    public Func<string> displayText;
    public bool enabled;
    public ButtonMode mode = ButtonMode.Toggle;

    public string GetDisplayText() => displayText?.Invoke() ?? buttonText;

    public static ButtonInfo Toggle(
        string name,
        Action tick = null,
        Action onEnable = null,
        Action onDisable = null,
        string tip = null,
        bool enabledByDefault = false)
    {
        return new ButtonInfo
        {
            buttonText = name,
            method = tick,
            enableMethod = onEnable,
            disableMethod = onDisable,
            toolTip = tip ?? name,
            enabled = enabledByDefault,
            mode = ButtonMode.Toggle,
        };
    }

    public static ButtonInfo Action(string name, Action action, string tip = null)
    {
        return new ButtonInfo
        {
            buttonText = name,
            method = action,
            toolTip = tip ?? name,
            mode = ButtonMode.Action,
        };
    }

    public static ButtonInfo Category(string name, string categoryName, string tip = null)
    {
        return Action(name, () => ModLabs.Menu.Main.SetCategory(categoryName), tip ?? $"Opens {categoryName}.");
    }
}

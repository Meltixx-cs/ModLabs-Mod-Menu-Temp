using ModLabs.Classes;
using UnityEngine;

namespace ModLabs.Menu;


public static class Settings
{
    // ---------- SAVED MENU BEHAVIOUR ----------
    [SavedSetting] public static bool rightHanded = Config.DefaultRightHanded;
    [SavedSetting] public static bool holdToOpen = Config.DefaultHoldToOpen;
    [SavedSetting] public static bool animateMenu = Config.DefaultAnimateMenu;
    [SavedSetting] public static bool menuSounds = Config.DefaultMenuSounds;
    [SavedSetting] public static bool buttonHaptics = Config.DefaultButtonHaptics;
    [SavedSetting] public static bool disableNotifications;

    [SavedSetting] public static KeyCode keyboardButton = Config.DefaultKeyboardButton;
    [SavedSetting] public static Vector3 menuScale = Config.DefaultMenuScale;
    [SavedSetting] public static float desktopDistance = Config.DefaultDesktopDistance;

    // ---------- CONFIG PROXIES ----------
    // Main.cs keeps familiar short names, but all editable values are centralized
    // in Config.cs.
    public static int ButtonsPerPage => Config.ButtonsPerPage;
    public static float ButtonRowSpacing => Config.ButtonRowSpacing;
    public static float OpenAnimationSpeed => Config.OpenAnimationSpeed;
    public static float CloseAnimationSpeed => Config.CloseAnimationSpeed;
    public static float ClickFlashSeconds => Config.ClickFlashSeconds;

    public static Color MainBlue => Config.MainColor;
    public static Color ButtonBlue => Config.ButtonColor;
    public static Color ActiveBlue => Config.ButtonEnabledColor;
    public static Color OutlineBlue => Config.OutlineColor;
    public static Color TextColor => Config.TextColor;
    public static Color VoidColor => Config.VoidColor;

    public static float OutlineWorldThickness => Config.OutlineWorldThickness;
    public static float OutlineDepthScale => Config.OutlineDepthScale;
    public static float DesktopRollCorrection => Config.DesktopRollCorrection;
    public static float ModelWidthMultiplier => Config.ModelWidthMultiplier;

    public static float TitleFontSize => Config.TitleFontSize;
    public static float CreditFontSize => Config.CreditFontSize;
    public static float ArrowFontSize => Config.ArrowFontSize;
    public static float ButtonFontSize => Config.ButtonFontSize;
    public static float ButtonFontSizeLong => Config.ButtonFontSizeLong;
    public static float ButtonFontSizeVeryLong => Config.ButtonFontSizeVeryLong;

    public static Font currentFont => Config.LegacyNotificationFont;
}

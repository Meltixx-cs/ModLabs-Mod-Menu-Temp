using System;
using System.Collections.Generic;
using System.Linq;
using ModLabs.Classes;

namespace ModLabs.Menu;


public static class Buttons
{
    private static readonly ButtonInfo[] MainButtons = BuildHomeButtons();
    private static readonly ButtonCategory[] Categories = BuildCategories();

    private static readonly Dictionary<string, ButtonCategory> CategoryLookup = BuildCategoryLookup();
    private static readonly Dictionary<string, ButtonInfo> ButtonLookup = BuildButtonLookup();
    private static readonly Dictionary<string, ButtonInfo> SavedToggleButtonLookup = BuildSavedToggleButtonLookup();

    public static IReadOnlyDictionary<string, ButtonInfo> SavedToggleButtons => SavedToggleButtonLookup;
    public static ButtonInfo[] AllButtons { get; } = BuildButtonArray();

    public static ButtonCategory GetCategory(string categoryName)
    {
        if (string.IsNullOrWhiteSpace(categoryName))
            return null;

        CategoryLookup.TryGetValue(categoryName, out ButtonCategory category);
        return category;
    }

    public static ButtonInfo[] GetButtonsForCategory(ButtonCategory category)
    {
        if (category == null)
            return Array.Empty<ButtonInfo>();

        return category.name.Equals(Config.EnabledModsCategoryName, StringComparison.OrdinalIgnoreCase)
            ? GetEnabledMods()
            : category.buttons;
    }


    public static ButtonInfo[] GetEnabledMods() =>
        Config.CommunityCategories
            .SelectMany(category => category.Buttons)
            .Where(button => button != null && button.mode == ButtonMode.Toggle && button.enabled)
            .ToArray();

    public static ButtonInfo GetIndex(string buttonText)
    {
        if (string.IsNullOrWhiteSpace(buttonText))
            return null;

        ButtonLookup.TryGetValue(buttonText, out ButtonInfo button);
        return button;
    }

    private static ButtonInfo[] BuildHomeButtons()
    {
        List<ButtonInfo> home = new();

        foreach (MenuCategoryConfig category in Config.CommunityCategories)
        {
            if (category.ShowOnHome)
            {
                home.Add(ButtonInfo.Category(
                    category.Name,
                    category.Name,
                    $"Opens {category.Name}."));
            }
        }

        home.Add(ButtonInfo.Category(
            Config.EnabledModsCategoryName,
            Config.EnabledModsCategoryName,
            "Shows every currently enabled mod."));

        return home.ToArray();
    }

    private static ButtonCategory[] BuildCategories()
    {
        List<ButtonCategory> result = new()
        {
            new ButtonCategory { name = "Main", buttons = MainButtons },
        };

        foreach (MenuCategoryConfig community in Config.CommunityCategories)
        {
            result.Add(new ButtonCategory
            {
                name = community.Name,
                buttons = community.Buttons,
            });
        }

        result.Add(new ButtonCategory
        {
            name = Config.EnabledModsCategoryName,
            buttons = Array.Empty<ButtonInfo>(),
        });

        result.Add(new ButtonCategory
        {
            name = "Settings",
            buttons = Config.SettingsButtons,
        });

        return result.ToArray();
    }

    private static Dictionary<string, ButtonCategory> BuildCategoryLookup()
    {
        Dictionary<string, ButtonCategory> lookup = new(StringComparer.OrdinalIgnoreCase);

        foreach (ButtonCategory category in Categories)
        {
            if (string.IsNullOrWhiteSpace(category.name))
                throw new InvalidOperationException("A ModLabs category does not have a name.");

            if (!lookup.TryAdd(category.name, category))
                throw new InvalidOperationException($"Duplicate ModLabs category: {category.name}");
        }

        return lookup;
    }

    private static Dictionary<string, ButtonInfo> BuildButtonLookup()
    {
        Dictionary<string, ButtonInfo> lookup = new(StringComparer.OrdinalIgnoreCase);

        foreach (ButtonCategory category in Categories)
        {
            foreach (ButtonInfo button in category.buttons)
            {
                if (button != null && !string.IsNullOrWhiteSpace(button.buttonText))
                    lookup.TryAdd(button.buttonText, button);
            }
        }

        return lookup;
    }

    private static ButtonInfo[] BuildButtonArray() =>
        Categories
            .SelectMany(category => category.buttons)
            .Where(button => button != null)
            .Distinct()
            .ToArray();

    private static Dictionary<string, ButtonInfo> BuildSavedToggleButtonLookup()
    {
        Dictionary<string, ButtonInfo> result = new(StringComparer.Ordinal);

        foreach (ButtonCategory category in Categories)
        {
            foreach (ButtonInfo button in category.buttons)
            {
                if (button == null || button.mode != ButtonMode.Toggle)
                    continue;

                string key = category.name + "/" + button.buttonText;

                if (!result.TryAdd(key, button))
                    throw new InvalidOperationException($"Duplicate saved toggle key: {key}");
            }
        }

        return result;
    }
}

using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BepInEx;
using GorillaLocomotion;
using HarmonyLib;
using ModLabs.Classes;
using ModLabs.Notifications;
using ModLabs.Tools;
using TMPro;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.UI;
using static ModLabs.Menu.Buttons;
using static ModLabs.Menu.Settings;
using Object = UnityEngine.Object;
using MenuPressButton = ModLabs.Classes.Button;

namespace ModLabs.Menu;


[HarmonyPatch(typeof(GTPlayer), "LateUpdate")]
public static class Main
{
    private const string BundleName = "modlabsmenu.bundle";
    private const string PrefabName = "ModLabsMenu";

    private static readonly Vector3 ModelRestPosition = Vector3.zero;

    public static GameObject menu;
    public static GameObject menuModel;
    public static int pageNumber;

    private static ButtonCategory currentCategory;

    private static AssetBundle modelBundle;
    private static GameObject modelPrefab;

    private static Transform menuName;
    private static GameObject developerCredit;
    private static Transform buttonsRoot;
    private static Transform buttonTemplate;

    private static readonly List<MenuSlot> Slots = new();
    private static readonly Dictionary<GameObject, Renderer> BackgroundRenderers = new();

    private static GameObject leftPageObject;
    private static GameObject rightPageObject;
    private static GameObject homeObject;
    private static GameObject settingsObject;
    private static GameObject disconnectObject;

    private static GameObject leftReference;
    private static GameObject rightReference;
    public static SphereCollider leftButtonCollider;
    public static SphereCollider rightButtonCollider;

    private static Material solidUiMaterial;
    private static Material outlineMaterial;

    private static MenuAudio menuAudio;

    private static bool menuClosing;
    private static bool vrOpenWasPressed;
    private static bool keyboardOpenWasPressed;
    private static bool vrToggleOpen;
    private static bool desktopToggleOpen;
    private static bool openedFromKeyboard;
    private static float animationProgress;
    private static float nextButtonPressTime;
    private static float nextDesktopClickTime;
    private static TMP_FontAsset runtimeFont;
    private static Material runtimeTextMaterial;
    private static string currentTitleText = Config.MenuName;
    private static float nextTitleGradientUpdateTime;
    private static GameObject titleIconObject;
    private static Texture2D titleIconTexture;
    private static Material titleIconMaterial;

    // Desktop interaction intentionally mirrors the original template's proven TPC/void path.
    public static Camera TPC;
    private static GameObject desktopVcam;
    private static bool desktopSceneActive;

    private static bool cursorStateSaved;
    private static CursorLockMode previousCursorLockMode;
    private static bool previousCursorVisible;

    private static readonly ButtonInfo PreviousPageButton = ButtonInfo.Action(
        "Previous Page",
        PreviousPage,
        "Moves one page left.");

    private static readonly ButtonInfo NextPageButton = ButtonInfo.Action(
        "Next Page",
        NextPage,
        "Moves one page right.");

    private static readonly ButtonInfo HomeButton = ButtonInfo.Action(
        "Home",
        () => SetCategory("Main"),
        "Returns to the ModLabs home page.");

    private static readonly ButtonInfo SettingsButton = ButtonInfo.Action(
        "Settings",
        () => SetCategory("Settings"),
        "Opens ModLabs settings.");

    private static readonly ButtonInfo DisconnectButton = ButtonInfo.Action(
        "Disconnect",
        () => NetworkSystem.Instance.ReturnToSinglePlayer(),
        "Leaves the current lobby.");

    public static ButtonCategory CurrentCategory => currentCategory ??= GetCategory("Main");

    public static void SetCategory(string categoryName)
    {
        ButtonCategory category = GetCategory(categoryName);
        if (category == null)
        {
            Debug.LogError($"[{Constants.Name}] Unknown category: {categoryName}");
            return;
        }

        currentCategory = category;
        pageNumber = 0;
        RefreshPage();
    }


    [HarmonyPrefix]
    public static void Prefix()
    {
        try
        {
            // Do not touch hand/camera objects before the player exists.
            if (GTPlayer.Instance == null || GorillaTagger.Instance == null)
                return;

            ExecuteEnabledMods();

            bool vrPressed = false;
            if (ControllerInputPoller.instance != null)
            {
                vrPressed =
                    (!rightHanded && ControllerInputPoller.instance.leftControllerSecondaryButton) ||
                    (rightHanded && ControllerInputPoller.instance.rightControllerSecondaryButton);
            }

            bool keyboardPressed = false;
            try
            {
                // This is the same desktop input path used by the working the original template.
                keyboardPressed = UnityInput.Current.GetKey(keyboardButton);
            }
            catch (Exception inputException)
            {
                Debug.LogWarning($"[{Constants.Name}] Desktop input read failed: {inputException.Message}");
            }

            bool keepOpen;
            bool keyboardMode;

            if (holdToOpen)
            {
                // Original template behaviour: hold Q / hold the controller menu button.
                desktopToggleOpen = false;
                vrToggleOpen = false;
                keepOpen = keyboardPressed || vrPressed;
                keyboardMode = keyboardPressed;
            }
            else
            {
                // Optional press-to-toggle mode, still driven from the safe LateUpdate patch.
                if (keyboardPressed && !keyboardOpenWasPressed)
                    desktopToggleOpen = !desktopToggleOpen;

                if (vrPressed && !vrOpenWasPressed)
                    vrToggleOpen = !vrToggleOpen;

                keepOpen = desktopToggleOpen || vrToggleOpen;
                keyboardMode = desktopToggleOpen;
            }

            keyboardOpenWasPressed = keyboardPressed;
            vrOpenWasPressed = vrPressed;

            if (menu != null)
            {
                UpdateMenuAnimation();
                UpdateAnimatedTitle();
            }

            if (menu == null)
            {
                if (keepOpen)
                {
                    openedFromKeyboard = keyboardMode;
                    CreateMenu();

                    if (menu != null)
                    {
                        CreateReferences();
                        RecenterMenu();
                    }
                }
            }
            else if (keepOpen)
            {
                if (menuClosing)
                    menuClosing = false;

                openedFromKeyboard = keyboardMode;
                CreateReferences();
                RecenterMenu();

                if (openedFromKeyboard && !menuClosing)
                    HandleDesktopClick();
            }
            else if (!menuClosing)
            {
                BeginCloseMenu();
            }
        }
        catch (Exception exception)
        {
            // Never let a template UI exception escape into Gorilla Tag's player loop.
            Debug.LogError($"[{Constants.Name}] Menu loop error: {exception}");
        }
    }

    public static void CreateMenu()
    {
        if (menu != null)
            return;

        if (!EnsurePrefabLoaded())
            return;

        menu = new GameObject("ModLabs_MenuRoot");
        menuModel = Object.Instantiate(modelPrefab, menu.transform, false);
        menuModel.name = PrefabName;

        // Keep the model invisible until every label/material/button is repaired.
        // This prevents the oversized white TMP flash that could appear for one frame.
        menuModel.SetActive(false);
        menuModel.transform.localPosition = ModelRestPosition;
        menuModel.transform.localRotation = Quaternion.identity;
        menuModel.transform.localScale = new Vector3(1f, 1f, ModelWidthMultiplier);

        menuAudio = menu.AddComponent<MenuAudio>();

        animationProgress = animateMenu ? 0f : 1f;
        menuClosing = false;

        if (!SetupModel())
        {
            Object.Destroy(menu);
            menu = null;
            menuModel = null;
            return;
        }

        RefreshPage();
        menuModel.SetActive(true);
        UpdateMenuAnimation(force: true);

        if (openedFromKeyboard)
            SetDesktopCursor(true);

        if (menuSounds)
            menuAudio?.PlayOpen();
    }

    private static bool EnsurePrefabLoaded()
    {
        if (modelPrefab != null)
            return true;

        modelBundle ??= MLAssetUtils.LoadAssetBundle(BundleName);

        if (modelBundle != null)
        {
            modelPrefab = modelBundle.LoadAsset<GameObject>(PrefabName);

            if (modelPrefab == null)
            {
                modelPrefab = modelBundle
                    .LoadAllAssets<GameObject>()
                    .FirstOrDefault(asset => asset != null && asset.name.Equals(PrefabName, StringComparison.OrdinalIgnoreCase));
            }
        }

        if (modelPrefab != null)
            return true;

        // Never replace the creator's prefab with a generated fake menu.
        // If ModLabsMenu cannot be loaded, leave the menu closed and put the real reason in BepInEx logs.
        Debug.LogError($"[{Constants.Name}] Could not load the real '{PrefabName}' prefab from '{BundleName}'. {MLAssetUtils.LastError}");
        return false;
    }

    private static bool SetupModel()
    {
        Slots.Clear();
        BackgroundRenderers.Clear();

        Transform baseObject = FindDeepChild(menuModel.transform, "Base");
        menuName = FindDeepChild(menuModel.transform, "MenuName");
        buttonsRoot = FindDeepChild(menuModel.transform, "Buttons");
        buttonTemplate = FindDeepChild(menuModel.transform, "Button1");

        leftPageObject = FindDeepChild(menuModel.transform, "LeftPageButton")?.gameObject;
        rightPageObject = FindDeepChild(menuModel.transform, "RightPageButton")?.gameObject;
        homeObject = FindDeepChild(menuModel.transform, "HomeButton")?.gameObject;
        settingsObject = FindDeepChild(menuModel.transform, "SettingsButton")?.gameObject;
        disconnectObject = FindDeepChild(menuModel.transform, "DisconnectButton")?.gameObject;

        string[] missing = new[]
        {
            baseObject == null ? "Base" : null,
            menuName == null ? "MenuName" : null,
            buttonsRoot == null ? "Buttons" : null,
            buttonTemplate == null ? "Button1" : null,
            leftPageObject == null ? "LeftPageButton" : null,
            rightPageObject == null ? "RightPageButton" : null,
            homeObject == null ? "HomeButton" : null,
            settingsObject == null ? "SettingsButton" : null,
            disconnectObject == null ? "DisconnectButton" : null,
        }.Where(value => value != null).ToArray();

        if (missing.Length > 0)
        {
            Debug.LogError($"[{Constants.Name}] Prefab is missing: {string.Join(", ", missing)}");
            return false;
        }

        EnsureUiMaterials();

        // Navigation objects in the authored prefab contain TMP objects with very different
        // scales than the normal mod buttons. Reusing those for < / > caused the enormous
        // white glyph that could cover the whole desktop view. Keep their icons, but never
        // repair/reactivate their imported text objects.
        DisableImportedText(leftPageObject);
        DisableImportedText(rightPageObject);
        if (HasChildNamed(homeObject.transform, "Icon")) DisableImportedText(homeObject);
        if (HasChildNamed(settingsObject.transform, "Icon")) DisableImportedText(settingsObject);
        if (HasChildNamed(disconnectObject.transform, "Icon")) DisableImportedText(disconnectObject);

        RepairAllPrefabText(menuModel);

        ApplyRendererColor(baseObject.GetComponent<Renderer>(), MainBlue);
        CreateOutline(baseObject.gameObject);

        // The original Button1 is treated only as a visual template.
        Vector3 firstPosition = buttonTemplate.localPosition;
        Quaternion firstRotation = buttonTemplate.localRotation;
        Vector3 firstScale = buttonTemplate.localScale;

        buttonTemplate.gameObject.SetActive(false);

        for (int i = 0; i < ButtonsPerPage; i++)
        {
            GameObject slotObject = Object.Instantiate(buttonTemplate.gameObject, buttonsRoot, false);
            slotObject.name = $"ML_ModButton_{i + 1}";
            slotObject.SetActive(true);
            slotObject.transform.localPosition = firstPosition + Vector3.down * (ButtonRowSpacing * i);
            slotObject.transform.localRotation = firstRotation;
            slotObject.transform.localScale = firstScale;

            PrepareClickable(slotObject, null, preserveFrontTexture: false);

            Slots.Add(new MenuSlot
            {
                gameObject = slotObject,
                press = slotObject.GetComponentInChildren<MenuPressButton>(true),
            });
        }

        PrepareClickable(leftPageObject, PreviousPageButton, preserveFrontTexture: false);
        PrepareClickable(rightPageObject, NextPageButton, preserveFrontTexture: false);
        PrepareClickable(homeObject, HomeButton, preserveFrontTexture: false);
        PrepareClickable(settingsObject, SettingsButton, preserveFrontTexture: false);
        PrepareClickable(disconnectObject, DisconnectButton, preserveFrontTexture: false);

        // Draw the page arrows as tiny meshes instead of TMP. This keeps them crisp and
        // completely eliminates scale explosions from imported TextMeshPro transforms.
        CreatePageArrowIcon(leftPageObject, pointsRight: true);
        CreatePageArrowIcon(rightPageObject, pointsRight: false);

        // The authored icon objects are kept exactly as they are. Only create text when an
        // icon genuinely does not exist.
        if (!HasChildNamed(homeObject.transform, "Icon")) SetText(homeObject, "HOME");
        if (!HasChildNamed(settingsObject.transform, "Icon")) SetText(settingsObject, "SET");
        if (!HasChildNamed(disconnectObject.transform, "Icon")) SetText(disconnectObject, "EXIT");

        CreateDeveloperCredit();
        CreateTitleIcon();

        return true;
    }

    private static void CreateDeveloperCredit()
    {
        if (menuName == null)
            return;

        developerCredit = Object.Instantiate(menuName.gameObject, menuName.parent, false);
        developerCredit.name = "DeveloperCredit";

        Transform transform = developerCredit.transform;
        Vector3 position = menuName.localPosition;
        position.y = -1.17f;
        transform.localPosition = position;
        transform.localRotation = menuName.localRotation;
        transform.localScale = menuName.localScale * 0.65f;

        SetText(developerCredit, Config.DeveloperCredit);
        StyleCreditText(developerCredit);
    }

    private static void CreateTitleIcon()
    {
        if (!Config.ShowTitleIcon || menuName == null)
            return;

        titleIconTexture ??= MLAssetUtils.LoadTexture(Config.TitleIconResourceName);
        if (titleIconTexture == null)
        {
            Debug.LogWarning($"[{Constants.Name}] Title icon texture could not be loaded.");
            return;
        }

        Transform existing = menuName.Find("ML_TitleIcon");
        if (existing != null)
            Object.Destroy(existing.gameObject);

        titleIconObject = GameObject.CreatePrimitive(PrimitiveType.Quad);
        titleIconObject.name = "ML_TitleIcon";
        titleIconObject.layer = 2; // visual only
        titleIconObject.transform.SetParent(menuName, false);
        titleIconObject.transform.localPosition = Config.TitleIconLocalPosition;
        titleIconObject.transform.localRotation = Quaternion.identity;
        titleIconObject.transform.localScale = Config.TitleIconLocalScale;

        Collider collider = titleIconObject.GetComponent<Collider>();
        if (collider != null)
            Object.Destroy(collider);

        MeshRenderer renderer = titleIconObject.GetComponent<MeshRenderer>();
        if (renderer == null)
            return;

        if (titleIconMaterial == null)
        {
            Shader shader =
                Shader.Find("Unlit/Transparent") ??
                Shader.Find("Sprites/Default") ??
                Shader.Find("UI/Default") ??
                Shader.Find("Standard");

            if (shader == null)
                return;

            titleIconMaterial = new Material(shader)
            {
                name = "ML_TitleIconMaterial",
                mainTexture = titleIconTexture,
                color = Color.white,
                renderQueue = 4001,
            };

            if (titleIconMaterial.HasProperty("_MainTex"))
                titleIconMaterial.SetTexture("_MainTex", titleIconTexture);
            if (titleIconMaterial.HasProperty("_Color"))
                titleIconMaterial.SetColor("_Color", Color.white);
        }

        renderer.sharedMaterial = titleIconMaterial;
        renderer.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
        renderer.receiveShadows = false;
        renderer.sortingOrder = 110;
    }

    private static void UpdateAnimatedTitle(bool force = false)
    {
        if (menuName == null)
            return;

        if (!force && Time.unscaledTime < nextTitleGradientUpdateTime)
            return;

        nextTitleGradientUpdateTime = Time.unscaledTime +
            1f / Mathf.Max(1f, Config.TitleGradientRefreshRate);

        TMP_Text tmp = EnsureTmpText(menuName.gameObject);
        if (tmp == null)
            return;

        tmp.richText = true;

        if (!Config.AnimatedTitleGradient || Config.TitleGradientColors == null || Config.TitleGradientColors.Length < 2)
        {
            tmp.text = currentTitleText ?? Config.MenuName;
            tmp.color = Config.TextColor;
            return;
        }

        string source = currentTitleText ?? Config.MenuName;
        float phase = Time.unscaledTime * Config.TitleGradientSpeed;
        StringBuilder builder = new(source.Length * 28);

        for (int i = 0; i < source.Length; i++)
        {
            char character = source[i];
            if (character == ' ')
            {
                builder.Append(' ');
                continue;
            }

            // Move the palette across the text continuously instead of snapping
            // each letter between colors.
            float palettePosition = Mathf.Repeat(
                phase + i / Mathf.Max(1f, source.Length - 1f) * (Config.TitleGradientColors.Length - 1),
                Config.TitleGradientColors.Length);

            int first = Mathf.FloorToInt(palettePosition) % Config.TitleGradientColors.Length;
            int second = (first + 1) % Config.TitleGradientColors.Length;
            float blend = palettePosition - Mathf.Floor(palettePosition);
            Color color = Color.Lerp(Config.TitleGradientColors[first], Config.TitleGradientColors[second], blend);

            builder.Append("<color=#");
            builder.Append(ColorUtility.ToHtmlStringRGB(color));
            builder.Append('>');
            builder.Append(character);
            builder.Append("</color>");
        }

        tmp.text = builder.ToString();
        tmp.color = Color.white;

        try
        {
            tmp.ForceMeshUpdate(true, true);
        }
        catch
        {
        }
    }

    private static void PrepareClickable(GameObject target, ButtonInfo info, bool preserveFrontTexture)
    {
        if (target == null)
            return;

        target.layer = 0;

        // Disable any imported collider on the visible mesh. A dedicated invisible hit surface
        // is more reliable for both desktop raycasts and VR finger/hand trigger presses.
        foreach (Collider imported in target.GetComponents<Collider>())
            imported.enabled = false;

        Transform oldSurface = target.transform.Find("ML_ClickSurface");
        if (oldSurface != null)
            Object.Destroy(oldSurface.gameObject);

        MeshFilter meshFilter = target.GetComponent<MeshFilter>();
        if (meshFilter != null && meshFilter.sharedMesh != null)
        {
            GameObject hitSurface = new("ML_ClickSurface");
            hitSurface.layer = 0;
            hitSurface.transform.SetParent(target.transform, false);
            hitSurface.transform.localPosition = Vector3.zero;
            hitSurface.transform.localRotation = Quaternion.identity;
            hitSurface.transform.localScale = Vector3.one;

            BoxCollider collider = hitSurface.AddComponent<BoxCollider>();
            collider.isTrigger = true;
            FitColliderToVisibleMesh(target, collider);

            MenuPressButton press = hitSurface.AddComponent<MenuPressButton>();
            press.relatedButton = info;
            press.visualTarget = target;
        }
        else
        {
            // Fallback for a future community model that has no MeshFilter on its button root.
            BoxCollider collider = target.AddComponent<BoxCollider>();
            collider.isTrigger = true;
            MenuPressButton press = target.AddComponent<MenuPressButton>();
            press.relatedButton = info;
            press.visualTarget = target;
        }

        Renderer background = CreateStyledBackground(target, preserveFrontTexture);
        if (background != null)
        {
            BackgroundRenderers[target] = background;
            ApplyRendererColor(background, ButtonBlue);
        }

        CreateOutline(target);
        SetTextColor(target, TextColor);
    }

    private static Renderer CreateStyledBackground(GameObject target, bool preserveFrontTexture)
    {
        MeshFilter meshFilter = target.GetComponent<MeshFilter>();
        MeshRenderer renderer = target.GetComponent<MeshRenderer>();

        if (renderer == null)
            return null;

        bool hasTexture = renderer.sharedMaterial != null && renderer.sharedMaterial.mainTexture != null;

        if (!preserveFrontTexture || !hasTexture || meshFilter == null || meshFilter.sharedMesh == null)
            return renderer;

        // Textured page icon materials keep their white transparent icon in front.
        // A plain blue copy behind them supplies the button body.
        GameObject backing = new("ML_ButtonBacking");
        backing.layer = 2;
        backing.transform.SetParent(target.transform, false);
        backing.transform.localPosition = Vector3.zero;
        backing.transform.localRotation = Quaternion.identity;
        backing.transform.localScale = new Vector3(0.985f, 1f, 1f);

        MeshFilter backingFilter = backing.AddComponent<MeshFilter>();
        backingFilter.sharedMesh = meshFilter.sharedMesh;

        MeshRenderer backingRenderer = backing.AddComponent<MeshRenderer>();
        backingRenderer.sharedMaterial = solidUiMaterial;
        ApplyRendererColor(backingRenderer, ButtonBlue);

        // Do not tint a white icon texture blue.
        ApplyRendererColor(renderer, Color.white);

        return backingRenderer;
    }

    private static void CreateOutline(GameObject target)
    {
        if (target == null || target.transform.Find("ML_OutlineStroke") != null)
            return;

        MeshFilter sourceFilter = target.GetComponent<MeshFilter>();
        Renderer sourceRenderer = target.GetComponent<Renderer>();
        if (sourceFilter == null || sourceFilter.sharedMesh == null || sourceRenderer == null)
            return;

        Bounds bounds = sourceFilter.sharedMesh.bounds;
        Vector3 worldSize = new(
            Mathf.Abs(bounds.size.x * target.transform.lossyScale.x),
            Mathf.Abs(bounds.size.y * target.transform.lossyScale.y),
            Mathf.Abs(bounds.size.z * target.transform.lossyScale.z));

        int depthAxis = SmallestAxis(worldSize);
        int firstAxis = depthAxis == 0 ? 1 : 0;
        int secondAxis = depthAxis == 2 ? 1 : 2;
        if (firstAxis == secondAxis)
            secondAxis = 2;

        GameObject outline = new("ML_OutlineStroke");
        outline.layer = 2; // visual only; never steal mouse raycasts
        outline.transform.SetParent(target.transform, false);
        outline.transform.SetSiblingIndex(0);

        MeshFilter filter = outline.AddComponent<MeshFilter>();
        filter.sharedMesh = sourceFilter.sharedMesh;

        MeshRenderer renderer = outline.AddComponent<MeshRenderer>();
        renderer.sharedMaterial = outlineMaterial;
        renderer.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
        renderer.receiveShadows = false;
        ApplyRendererColor(renderer, OutlineBlue);

        // Inflate only the two visible axes by a constant world-space amount. This produces a
        // much cleaner, even border than stacking eight offset copies of the mesh.
        Vector3 scale = Vector3.one;
        float firstWorld = Mathf.Max(GetAxis(worldSize, firstAxis), 0.0001f);
        float secondWorld = Mathf.Max(GetAxis(worldSize, secondAxis), 0.0001f);
        SetAxis(ref scale, firstAxis, 1f + (OutlineWorldThickness * 2f / firstWorld));
        SetAxis(ref scale, secondAxis, 1f + (OutlineWorldThickness * 2f / secondWorld));
        SetAxis(ref scale, depthAxis, OutlineDepthScale);
        outline.transform.localScale = scale;

        // Scale around the actual mesh center instead of the object's pivot so off-center Blender
        // pivots cannot make one side of the outline thicker than the other.
        outline.transform.localPosition = bounds.center - Vector3.Scale(bounds.center, scale);
        outline.transform.localRotation = Quaternion.identity;
    }

    private static int SmallestAxis(Vector3 value)
    {
        if (value.x <= value.y && value.x <= value.z) return 0;
        if (value.y <= value.x && value.y <= value.z) return 1;
        return 2;
    }

    private static float GetAxis(Vector3 value, int axis) =>
        axis == 0 ? value.x : axis == 1 ? value.y : value.z;

    private static void SetAxis(ref Vector3 value, int axis, float amount)
    {
        if (axis == 0) value.x = amount;
        else if (axis == 1) value.y = amount;
        else value.z = amount;
    }

    private static void FitColliderToVisibleMesh(GameObject target, BoxCollider collider)
    {
        MeshFilter meshFilter = target.GetComponent<MeshFilter>();
        if (meshFilter == null || meshFilter.sharedMesh == null)
            return;

        Bounds bounds = meshFilter.sharedMesh.bounds;
        collider.center = bounds.center;

        Vector3 size = bounds.size;
        int depthAxis = SmallestAxis(new Vector3(
            Mathf.Abs(size.x * target.transform.lossyScale.x),
            Mathf.Abs(size.y * target.transform.lossyScale.y),
            Mathf.Abs(size.z * target.transform.lossyScale.z)));

        size *= 1.12f;
        SetAxis(ref size, depthAxis, Mathf.Max(GetAxis(size, depthAxis) * 2.5f, 0.002f));
        collider.size = size;
    }

    private static void EnsureUiMaterials()
    {
        if (solidUiMaterial != null && outlineMaterial != null)
            return;

        Shader shader = Shader.Find("GorillaTag/UberShader") ?? Shader.Find("Standard");
        solidUiMaterial = new Material(shader) { name = "ML_SolidUI" };
        outlineMaterial = new Material(shader) { name = "ML_Outline" };
        ApplyMaterialColor(solidUiMaterial, ButtonBlue);
        ApplyMaterialColor(outlineMaterial, OutlineBlue);
    }

    private static void RefreshPage()
    {
        if (menu == null || Slots.Count == 0)
            return;

        ButtonInfo[] visibleButtons = GetButtonsForCategory(CurrentCategory);
        int lastPage = GetLastPage(visibleButtons.Length);

        pageNumber = Mathf.Clamp(pageNumber, 0, lastPage);
        int startIndex = pageNumber * ButtonsPerPage;

        for (int i = 0; i < Slots.Count; i++)
        {
            MenuSlot slot = Slots[i];
            int index = startIndex + i;

            if (index >= visibleButtons.Length)
            {
                slot.gameObject.SetActive(false);
                slot.press.relatedButton = null;
                continue;
            }

            ButtonInfo info = visibleButtons[index];
            slot.gameObject.SetActive(true);
            slot.press.relatedButton = info;

            SetText(slot.gameObject, info.GetDisplayText());
            StyleButtonText(slot.gameObject);
            SetButtonColor(slot.gameObject, info.mode == ButtonMode.Toggle && info.enabled ? ActiveBlue : ButtonBlue);
        }

        // Keep the branding large and readable. The current section is already obvious
        // from the visible buttons, while page numbers are shown only when needed.
        currentTitleText = lastPage > 0
            ? $"{Config.MenuName} [{pageNumber + 1}/{lastPage + 1}]"
            : Config.MenuName;

        StyleTitleText(menuName?.gameObject);
        UpdateAnimatedTitle(force: true);

        SetButtonColor(leftPageObject, ButtonBlue);
        SetButtonColor(rightPageObject, ButtonBlue);
        SetButtonColor(homeObject, CurrentCategory.name == "Main" ? ActiveBlue : ButtonBlue);
        SetButtonColor(settingsObject, CurrentCategory.name == "Settings" ? ActiveBlue : ButtonBlue);
        SetButtonColor(disconnectObject, ButtonBlue);
    }

    private static int GetLastPage(int count) => count <= 0 ? 0 : (count - 1) / ButtonsPerPage;

    private static void PreviousPage()
    {
        ButtonInfo[] buttons = GetButtonsForCategory(CurrentCategory);
        int lastPage = GetLastPage(buttons.Length);
        pageNumber--;
        if (pageNumber < 0)
            pageNumber = lastPage;
        RefreshPage();
    }

    private static void NextPage()
    {
        ButtonInfo[] buttons = GetButtonsForCategory(CurrentCategory);
        int lastPage = GetLastPage(buttons.Length);
        pageNumber++;
        if (pageNumber > lastPage)
            pageNumber = 0;
        RefreshPage();
    }

    public static void RecreateMenu() => RefreshPage();

    public static void QueueButtonPress(ButtonInfo target, GameObject sourceObject, bool? rightHand)
    {
        if (target == null || Time.unscaledTime < nextButtonPressTime)
            return;

        nextButtonPressTime = Time.unscaledTime + 0.16f;

        if (rightHand.HasValue && buttonHaptics)
        {
            try
            {
                GorillaTagger.Instance.StartVibration(
                    rightHand.Value,
                    GorillaTagger.Instance.tagHapticStrength / 2f,
                    GorillaTagger.Instance.tagHapticDuration / 2f);
            }
            catch
            {
                // Haptics are optional.
            }
        }

        if (menuSounds)
        {
            bool playedGameTap = false;

            try
            {
                // The original the original template uses hand tap 8, which is the wood/stump-like click.
                VRRig.LocalRig.PlayHandTapLocal(8, rightHand ?? false, 0.4f);
                playedGameTap = true;
            }
            catch
            {
                // Desktop/local rig may not have the hand-tap path available; use the generated fallback.
            }

            if (!playedGameTap)
                menuAudio?.PlayClick();
        }

        if (CoroutineManager.Instance != null)
            CoroutineManager.Instance.StartCoroutine(PressRoutine(target, sourceObject));
        else
            Toggle(target);
    }

    private static IEnumerator PressRoutine(ButtonInfo target, GameObject sourceObject)
    {
        if (sourceObject != null)
            SetButtonColor(sourceObject, ActiveBlue);

        yield return new WaitForSecondsRealtime(ClickFlashSeconds);

        Toggle(target);
    }

    public static void Toggle(string buttonText, bool? incrementDirection = null)
    {
        ButtonInfo button = GetIndex(buttonText);
        if (button == null)
        {
            Debug.LogError($"[{Constants.Name}] Button not found: {buttonText}");
            return;
        }

        Toggle(button, incrementDirection);
    }

    public static void Toggle(ButtonInfo target, bool? incrementDirection = null)
    {
        if (target == null)
            return;

        switch (target.mode)
        {
            case ButtonMode.Toggle:
                target.enabled = !target.enabled;

                try
                {
                    if (target.enabled)
                        target.enableMethod?.Invoke();
                    else
                        target.disableMethod?.Invoke();
                }
                catch (Exception exception)
                {
                    Debug.LogError($"[{Constants.Name}] State change failed for {target.buttonText}: {exception}");
                }

                try
                {
                    NotifiLib.SendNotification(
                        target.enabled
                            ? $"<color=#6BAEFF>[ENABLE]</color> {target.toolTip}"
                            : $"<color=#4C6A8A>[DISABLE]</color> {target.toolTip}");
                }
                catch
                {
                    // Notification HUD may not be initialized yet.
                }
                break;

            case ButtonMode.Action:
                try
                {
                    target.method?.Invoke();
                }
                catch (Exception exception)
                {
                    Debug.LogError($"[{Constants.Name}] Action failed for {target.buttonText}: {exception}");
                }
                break;

            case ButtonMode.Incremental:
                try
                {
                    target.incrementMethod?.Invoke(incrementDirection ?? true);
                }
                catch (Exception exception)
                {
                    Debug.LogError($"[{Constants.Name}] Increment failed for {target.buttonText}: {exception}");
                }
                break;
        }

        Preferences.Save();
        RefreshPage();
    }

    private static void ExecuteEnabledMods()
    {
        foreach (ButtonInfo button in AllButtons)
        {
            if (button.mode != ButtonMode.Toggle || !button.enabled || button.method == null)
                continue;

            try
            {
                button.method.Invoke();
            }
            catch (Exception exception)
            {
                Debug.LogError($"[{Constants.Name}] Mod tick failed ({button.buttonText}): {exception.Message}");
            }
        }
    }

    private static void RecenterMenu()
    {
        if (menu == null)
            return;

        if (openedFromKeyboard)
        {
            if (!EnsureDesktopScene())
                return;

            // Keep the shoulder camera parked in the same isolated desktop scene used by the
            // working ii template, then redraw a short-lived backdrop behind the menu each frame.
            TPC.transform.position = new Vector3(-999f, -999f, -999f);
            TPC.transform.rotation = Quaternion.identity;
            DrawDesktopVoid();

            menu.transform.SetParent(TPC.transform, false);
            menu.transform.localPosition = new Vector3(0f, -0.02f, desktopDistance);
            menu.transform.localRotation =
                Quaternion.AngleAxis(DesktopRollCorrection, Vector3.forward) *
                Quaternion.Euler(-90f, 90f, 0f);

            SetDesktopCursor(true);
            SetReferenceActivity(false, false);
            return;
        }

        if (desktopSceneActive)
            ExitDesktopScene();

        menu.transform.SetParent(null, true);

        Transform hand = rightHanded
            ? GorillaTagger.Instance.rightHandTransform
            : GorillaTagger.Instance.leftHandTransform;

        if (hand == null)
            return;

        menu.transform.position = hand.position;

        if (rightHanded)
            menu.transform.rotation = hand.rotation * Quaternion.Euler(0f, 0f, 180f);
        else
            menu.transform.rotation = hand.rotation;

        // Like the original template, the opposite hand is the pressing hand.
        SetReferenceActivity(rightHanded, !rightHanded);
    }

    private static bool EnsureDesktopScene()
    {
        if (desktopSceneActive && TPC != null)
            return true;

        try
        {
            TPC = GameObject.Find("Player Objects/Third Person Camera/Shoulder Camera")?.GetComponent<Camera>();
        }
        catch
        {
            TPC = null;
        }

        if (TPC == null)
            return false;

        GameObject shoulderCamera = GameObject.Find("Shoulder Camera");
        desktopVcam = shoulderCamera?.transform.Find("CM vcam1")?.gameObject;
        desktopVcam?.SetActive(false);

        TPC.transform.position = new Vector3(-999f, -999f, -999f);
        TPC.transform.rotation = Quaternion.identity;
        desktopSceneActive = true;
        return true;
    }

    private static void DrawDesktopVoid()
    {
        if (TPC == null)
            return;

        // This intentionally follows the original ii template: the backdrop is recreated behind
        // the menu and destroyed almost immediately. It cannot accumulate, drift, or end up in
        // front of the UI after a camera/menu transform changes.
        GameObject bg = GameObject.CreatePrimitive(PrimitiveType.Cube);
        bg.name = "ModLabs_DesktopVoidFrame";
        bg.layer = 2;

        Collider collider = bg.GetComponent<Collider>();
        if (collider != null)
            Object.Destroy(collider);

        bg.transform.localScale = new Vector3(10f, 10f, 0.01f);
        bg.transform.position = TPC.transform.position + TPC.transform.forward * 1.0f;
        bg.transform.rotation = TPC.transform.rotation;

        Renderer renderer = bg.GetComponent<Renderer>();
        if (renderer != null)
        {
            try
            {
                renderer.material.color = VoidColor;
                ApplyMaterialColor(renderer.material, VoidColor);
            }
            catch
            {
                // The stock primitive material is enough for the backdrop if a custom property
                // is unavailable on this Gorilla Tag build.
            }
        }

        Object.Destroy(bg, 0.05f);
    }

    private static void ExitDesktopScene()
    {
        if (desktopVcam != null)
            desktopVcam.SetActive(true);

        desktopVcam = null;
        TPC = null;
        desktopSceneActive = false;
        SetDesktopCursor(false);
    }

    private static void HandleDesktopClick()
    {
        if (Mouse.current == null || !Mouse.current.leftButton.isPressed || TPC == null)
            return;

        if (Time.unscaledTime < nextDesktopClickTime)
            return;

        // The menu was repositioned this frame; sync before raycasting so the
        // collider locations match what is actually visible on screen.
        Physics.SyncTransforms();

        Ray ray = TPC.ScreenPointToRay(Mouse.current.position.ReadValue());
        RaycastHit[] hits = Physics.RaycastAll(ray, 100f, ~0, QueryTriggerInteraction.Collide);

        if (hits == null || hits.Length == 0)
            return;

        Array.Sort(hits, (a, b) => a.distance.CompareTo(b.distance));

        foreach (RaycastHit hit in hits)
        {
            if (hit.collider == null)
                continue;

            MenuPressButton button =
                hit.collider.GetComponent<MenuPressButton>() ??
                hit.collider.GetComponentInParent<MenuPressButton>();

            if (button == null || button.relatedButton == null)
                continue;

            nextDesktopClickTime = Time.unscaledTime + 0.18f;
            button.PressDesktop();
            return;
        }
    }

    private static void UpdateMenuAnimation(bool force = false)
    {
        if (menu == null)
            return;

        if (!animateMenu)
        {
            animationProgress = menuClosing ? 0f : 1f;
        }
        else if (!force)
        {
            float speed = menuClosing ? CloseAnimationSpeed : OpenAnimationSpeed;
            animationProgress = Mathf.MoveTowards(
                animationProgress,
                menuClosing ? 0f : 1f,
                Time.unscaledDeltaTime * speed);
        }

        float smooth = animationProgress * animationProgress * (3f - 2f * animationProgress);
        float scaleFactor = Mathf.Lerp(0.86f, 1f, smooth);
        menu.transform.localScale = menuScale * scaleFactor;

        if (menuModel != null)
        {
            float slide = (1f - smooth) * -0.055f;
            menuModel.transform.localPosition = ModelRestPosition + new Vector3(0f, slide, 0f);
            menuModel.transform.localRotation = Quaternion.Euler(0f, (1f - smooth) * 3.5f, 0f);
        }

        if (menuClosing && animationProgress <= 0f)
            FinishCloseMenu();
    }



    private static void BeginCloseMenu()
    {
        if (menu == null || menuClosing)
            return;

        menuClosing = true;

        if (menuSounds)
            menuAudio?.PlayClose();

        if (!animateMenu)
            FinishCloseMenu();
    }

    private static void FinishCloseMenu()
    {
        if (menu == null)
            return;

        GameObject oldMenu = menu;

        menu = null;
        menuModel = null;
        menuName = null;
        developerCredit = null;
        titleIconObject = null;
        buttonsRoot = null;
        buttonTemplate = null;
        leftPageObject = null;
        rightPageObject = null;
        homeObject = null;
        settingsObject = null;
        disconnectObject = null;
        menuAudio = null;
        menuClosing = false;
        openedFromKeyboard = false;
        desktopToggleOpen = false;
        vrToggleOpen = false;

        Slots.Clear();
        BackgroundRenderers.Clear();
        DestroyReferences();
        ExitDesktopScene();

        Object.Destroy(oldMenu);
    }

    private static void CreateReferences()
    {
        if (GorillaTagger.Instance == null)
            return;

        if (leftReference == null && GorillaTagger.Instance.leftHandTransform != null)
            leftReference = CreateReference(GorillaTagger.Instance.leftHandTransform, out leftButtonCollider);

        if (rightReference == null && GorillaTagger.Instance.rightHandTransform != null)
            rightReference = CreateReference(GorillaTagger.Instance.rightHandTransform, out rightButtonCollider);
    }

    private static GameObject CreateReference(Transform hand, out SphereCollider collider)
    {
        GameObject reference = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        reference.name = "ML_ButtonReference";
        reference.transform.SetParent(hand, false);
        reference.transform.localPosition = new Vector3(0f, -0.1f, 0f);
        reference.transform.localRotation = Quaternion.identity;
        reference.transform.localScale = Vector3.one * 0.01f;

        Renderer renderer = reference.GetComponent<Renderer>();
        if (renderer != null)
            renderer.enabled = false;

        collider = reference.GetComponent<SphereCollider>();
        collider.isTrigger = false;

        // the original template uses a hand reference sphere. A kinematic Rigidbody makes the
        // trigger contact reliable even when the parent hand is moved by tracking.
        Rigidbody body = reference.AddComponent<Rigidbody>();
        body.isKinematic = true;
        body.useGravity = false;

        return reference;
    }

    private static void SetReferenceActivity(bool leftActive, bool rightActive)
    {
        if (leftReference != null)
            leftReference.SetActive(leftActive);
        if (rightReference != null)
            rightReference.SetActive(rightActive);
    }

    private static void DestroyReferences()
    {
        if (leftReference != null)
            Object.Destroy(leftReference);
        if (rightReference != null)
            Object.Destroy(rightReference);

        leftReference = null;
        rightReference = null;
        leftButtonCollider = null;
        rightButtonCollider = null;
    }

    public static bool TryGetReferenceHand(Collider collider, out bool rightHand)
    {
        if (collider != null && collider == rightButtonCollider)
        {
            rightHand = true;
            return true;
        }

        if (collider != null && collider == leftButtonCollider)
        {
            rightHand = false;
            return true;
        }

        rightHand = false;
        return false;
    }

    private static void SetDesktopCursor(bool enabled)
    {
        if (enabled)
        {
            if (!cursorStateSaved)
            {
                previousCursorLockMode = Cursor.lockState;
                previousCursorVisible = Cursor.visible;
                cursorStateSaved = true;
            }

            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;
            return;
        }

        if (!cursorStateSaved)
            return;

        Cursor.lockState = previousCursorLockMode;
        Cursor.visible = previousCursorVisible;
        cursorStateSaved = false;
    }

    private static Transform FindDeepChild(Transform parent, string name)
    {
        if (parent == null)
            return null;

        if (parent.name.Equals(name, StringComparison.OrdinalIgnoreCase))
            return parent;

        for (int i = 0; i < parent.childCount; i++)
        {
            Transform result = FindDeepChild(parent.GetChild(i), name);
            if (result != null)
                return result;
        }

        return null;
    }

    private static bool HasChildNamed(Transform parent, string childName) =>
        FindDeepChild(parent, childName) != null;

    private static void DisableImportedText(GameObject root)
    {
        if (root == null)
            return;

        foreach (TMP_Text tmp in root.GetComponentsInChildren<TMP_Text>(true))
        {
            if (tmp == null)
                continue;

            tmp.text = string.Empty;
            tmp.enabled = false;
            tmp.gameObject.SetActive(false);
        }

        foreach (Text text in root.GetComponentsInChildren<Text>(true))
        {
            if (text == null)
                continue;

            text.text = string.Empty;
            text.enabled = false;
            text.gameObject.SetActive(false);
        }
    }

    private static void CreatePageArrowIcon(GameObject target, bool pointsRight)
    {
        if (target == null)
            return;

        Transform old = target.transform.Find("ML_PageArrow");
        if (old != null)
            Object.Destroy(old.gameObject);

        Transform oldOutline = target.transform.Find("ML_PageArrow_Outline");
        if (oldOutline != null)
            Object.Destroy(oldOutline.gameObject);

        MeshFilter source = target.GetComponent<MeshFilter>();
        if (source == null || source.sharedMesh == null)
            return;

        Bounds bounds = source.sharedMesh.bounds;
        Vector3 worldSize = new(
            Mathf.Abs(bounds.size.x * target.transform.lossyScale.x),
            Mathf.Abs(bounds.size.y * target.transform.lossyScale.y),
            Mathf.Abs(bounds.size.z * target.transform.lossyScale.z));

        int depthAxis = SmallestAxis(worldSize);
        int axisA = depthAxis == 0 ? 1 : 0;
        int axisB = depthAxis == 2 ? 1 : 2;
        if (axisA == axisB)
            axisB = 2;

        // Point along the larger of the two visible axes; use the smaller axis for height.
        float worldA = Mathf.Abs(GetAxis(bounds.size, axisA) * GetAxis(target.transform.lossyScale, axisA));
        float worldB = Mathf.Abs(GetAxis(bounds.size, axisB) * GetAxis(target.transform.lossyScale, axisB));
        int horizontalAxis = worldA >= worldB ? axisA : axisB;
        int verticalAxis = horizontalAxis == axisA ? axisB : axisA;

        // Infer which side of the mesh is the authored front from the old text anchor when possible.
        float frontSign = 1f;
        TMP_Text imported = target.GetComponentsInChildren<TMP_Text>(true).FirstOrDefault();
        if (imported != null)
        {
            float textDepth = GetAxis(imported.transform.localPosition, depthAxis);
            float centerDepth = GetAxis(bounds.center, depthAxis);
            if (Mathf.Abs(textDepth - centerDepth) > 0.000001f)
                frontSign = Mathf.Sign(textDepth - centerDepth);
        }

        float halfWidth = Mathf.Abs(GetAxis(bounds.size, horizontalAxis)) * 0.115f;
        float halfHeight = Mathf.Abs(GetAxis(bounds.size, verticalAxis)) * 0.30f;
        float frontDepth = GetAxis(bounds.center, depthAxis) +
                           frontSign * (Mathf.Abs(GetAxis(bounds.extents, depthAxis)) + Mathf.Max(0.00004f, Mathf.Abs(GetAxis(bounds.size, depthAxis)) * 0.08f));

        Vector3 center = bounds.center;
        SetAxis(ref center, depthAxis, frontDepth);

        // One clean white triangle. No black fill, no image background, and no TMP glyph.
        CreateArrowLayer(target.transform, center, horizontalAxis, verticalAxis, depthAxis,
            halfWidth, halfHeight, pointsRight, Config.PageArrowColor, "ML_PageArrow", frontSign * 0.00001f);
    }

    private static void CreateArrowLayer(
        Transform parent,
        Vector3 center,
        int horizontalAxis,
        int verticalAxis,
        int depthAxis,
        float halfWidth,
        float halfHeight,
        bool pointsRight,
        Color color,
        string objectName,
        float depthNudge)
    {
        GameObject arrow = new(objectName);
        arrow.layer = 2; // Ignore Raycast: visual only.
        arrow.transform.SetParent(parent, false);
        arrow.transform.localPosition = Vector3.zero;
        arrow.transform.localRotation = Quaternion.identity;
        arrow.transform.localScale = Vector3.one;

        Vector3 c = center;
        SetAxis(ref c, depthAxis, GetAxis(c, depthAxis) + depthNudge);

        float direction = pointsRight ? 1f : -1f;
        Vector3 tip = c;
        Vector3 topBack = c;
        Vector3 bottomBack = c;
        SetAxis(ref tip, horizontalAxis, GetAxis(c, horizontalAxis) + halfWidth * direction);
        SetAxis(ref topBack, horizontalAxis, GetAxis(c, horizontalAxis) - halfWidth * direction);
        SetAxis(ref bottomBack, horizontalAxis, GetAxis(c, horizontalAxis) - halfWidth * direction);
        SetAxis(ref topBack, verticalAxis, GetAxis(c, verticalAxis) + halfHeight);
        SetAxis(ref bottomBack, verticalAxis, GetAxis(c, verticalAxis) - halfHeight);

        Mesh mesh = new()
        {
            name = objectName + "Mesh",
            vertices = new[] { tip, topBack, bottomBack },
            triangles = new[] { 0, 1, 2, 0, 2, 1 }
        };
        mesh.RecalculateBounds();
        mesh.RecalculateNormals();

        MeshFilter filter = arrow.AddComponent<MeshFilter>();
        filter.sharedMesh = mesh;

        MeshRenderer renderer = arrow.AddComponent<MeshRenderer>();
        Shader shader = Shader.Find("GorillaTag/UberShader") ?? Shader.Find("Standard");
        Material material = new(shader) { name = objectName + "Material" };
        renderer.sharedMaterial = material;
        renderer.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
        renderer.receiveShadows = false;
        ApplyMaterialColor(material, color);
    }

    private static TMP_FontAsset GetRuntimeFont()
    {
        if (runtimeFont != null)
            return runtimeFont;

        try
        {
            TMP_FontAsset[] loadedFonts = Resources.FindObjectsOfTypeAll<TMP_FontAsset>()
                .Where(font => font != null && font.material != null)
                .ToArray();

            foreach (string hint in Config.FontNameHints)
            {
                if (string.IsNullOrWhiteSpace(hint))
                    continue;

                runtimeFont = loadedFonts.FirstOrDefault(font =>
                    font.name.IndexOf(hint, StringComparison.OrdinalIgnoreCase) >= 0);

                if (runtimeFont != null)
                    break;
            }
        }
        catch
        {
        }

        if (runtimeFont == null)
        {
            try
            {
                runtimeFont = TMP_Settings.defaultFontAsset;
            }
            catch
            {
            }
        }

        if (runtimeFont == null)
        {
            runtimeFont = Resources
                .FindObjectsOfTypeAll<TMP_FontAsset>()
                .FirstOrDefault(font => font != null && font.material != null);
        }

        return runtimeFont;
    }

    private static Material GetRuntimeTextMaterial(TMP_FontAsset font)
    {
        if (runtimeTextMaterial != null)
            return runtimeTextMaterial;

        if (font?.material == null)
            return null;

        runtimeTextMaterial = new Material(font.material)
        {
            name = "ML_RuntimeText"
        };

        if (runtimeTextMaterial.HasProperty("_FaceColor"))
            runtimeTextMaterial.SetColor("_FaceColor", Config.TextColor);
        if (runtimeTextMaterial.HasProperty("_OutlineColor"))
            runtimeTextMaterial.SetColor("_OutlineColor", Config.TextOutlineColor);
        if (runtimeTextMaterial.HasProperty("_OutlineWidth"))
            runtimeTextMaterial.SetFloat("_OutlineWidth", Config.TextOutlineWidth);
        if (runtimeTextMaterial.HasProperty("_ZTestMode"))
            runtimeTextMaterial.SetFloat("_ZTestMode", 8f); // Always: menu labels never hide behind their button face.

        runtimeTextMaterial.EnableKeyword("OUTLINE_ON");
        runtimeTextMaterial.renderQueue = 4000;
        return runtimeTextMaterial;
    }

    private static void StyleButtonText(GameObject root)
    {
        TMP_Text tmp = EnsureTmpText(root);
        if (tmp == null)
            return;

        // Fixed sizes stop TMP from visibly shrinking/growing whenever RefreshPage runs.
        tmp.enableAutoSizing = false;
        int length = tmp.text?.Length ?? 0;
        tmp.fontSize = length > 22
            ? ButtonFontSizeVeryLong
            : length > 15
                ? ButtonFontSizeLong
                : ButtonFontSize;
        tmp.fontStyle = Config.TextFontStyle;
        tmp.fontWeight = Config.TextFontWeight;
        tmp.alignment = TextAlignmentOptions.Center;
        tmp.textWrappingMode = TextWrappingModes.NoWrap;
        tmp.overflowMode = TextOverflowModes.Overflow;
        tmp.characterSpacing = Config.ButtonCharacterSpacing;
        tmp.color = TextColor;
        tmp.ForceMeshUpdate(true, true);
    }

    private static void StyleTitleText(GameObject root)
    {
        TMP_Text tmp = EnsureTmpText(root);
        if (tmp == null)
            return;

        tmp.enableAutoSizing = false;
        tmp.fontSize = TitleFontSize;
        tmp.fontStyle = Config.TextFontStyle;
        tmp.fontWeight = Config.TextFontWeight;
        tmp.alignment = TextAlignmentOptions.Center;
        tmp.textWrappingMode = TextWrappingModes.NoWrap;
        tmp.overflowMode = TextOverflowModes.Overflow;
        tmp.characterSpacing = Config.TitleCharacterSpacing;
        tmp.color = TextColor;
        tmp.ForceMeshUpdate(true, true);
    }

    private static void StyleArrowText(GameObject root)
    {
        TMP_Text tmp = EnsureTmpText(root);
        if (tmp == null)
            return;

        tmp.enableAutoSizing = false;
        tmp.fontSize = ArrowFontSize;
        tmp.fontStyle = FontStyles.Bold;

        RectTransform rect = tmp.rectTransform;
        if (rect != null)
        {
            Vector2 size = rect.sizeDelta;
            size.x = Mathf.Max(size.x, 12f);
            size.y = Mathf.Max(size.y, 6f);
            rect.sizeDelta = size;
        }
        tmp.alignment = TextAlignmentOptions.Center;
        tmp.overflowMode = TextOverflowModes.Overflow;
        tmp.color = TextColor;
        tmp.ForceMeshUpdate(true, true);
    }

    private static void StyleCreditText(GameObject root)
    {
        TMP_Text tmp = EnsureTmpText(root);
        if (tmp == null)
            return;

        tmp.enableAutoSizing = false;
        tmp.fontSize = CreditFontSize;
        tmp.fontStyle = Config.TextFontStyle;
        tmp.fontWeight = Config.TextFontWeight;
        tmp.alignment = TextAlignmentOptions.Center;
        tmp.textWrappingMode = TextWrappingModes.NoWrap;
        tmp.overflowMode = TextOverflowModes.Overflow;
        tmp.characterSpacing = 0f;
        tmp.color = TextColor;
        tmp.ForceMeshUpdate(true, true);
    }

    private static TMP_Text FindTmpText(GameObject root)
    {
        if (root == null)
            return null;

        TMP_Text own = root.GetComponent<TMP_Text>();
        if (own != null)
            return own;

        TMP_Text[] all = root.GetComponentsInChildren<TMP_Text>(true);
        return all.FirstOrDefault(text =>
            text != null &&
            (text.gameObject.name.Equals("Text", StringComparison.OrdinalIgnoreCase) ||
             text.gameObject.name.IndexOf("Text", StringComparison.OrdinalIgnoreCase) >= 0))
            ?? all.FirstOrDefault();
    }

    private static TMP_Text EnsureTmpText(GameObject root)
    {
        if (root == null)
            return null;

        TMP_Text tmp = FindTmpText(root);

        if (tmp == null)
        {
            Transform anchor =
                FindDeepChild(root.transform, "Text") ??
                root.transform;

            try
            {
                tmp = anchor.gameObject.AddComponent<TextMeshPro>();
            }
            catch (Exception exception)
            {
                Debug.LogWarning($"[{Constants.Name}] Could not add runtime TMP text to {root.name}: {exception.Message}");
                return null;
            }
        }

        RepairTmp(tmp);
        return tmp;
    }

    private static void RepairAllPrefabText(GameObject root)
    {
        if (root == null)
            return;

        foreach (TMP_Text tmp in root.GetComponentsInChildren<TMP_Text>(true))
        {
            // Intentionally disabled imported navigation labels stay disabled. Their odd authored
            // transforms are replaced by controlled mesh icons instead of being reactivated here.
            if (tmp == null || !tmp.gameObject.activeSelf)
                continue;

            RepairTmp(tmp);
        }
    }

    private static void RepairTmp(TMP_Text tmp)
    {
        if (tmp == null)
            return;

        TMP_FontAsset font = GetRuntimeFont();
        if (font != null)
        {
            try
            {
                tmp.font = font;
                Material material = GetRuntimeTextMaterial(font);
                if (material != null)
                    tmp.fontSharedMaterial = material;
            }
            catch
            {
            }
        }

        tmp.gameObject.SetActive(true);
        tmp.enabled = true;
        tmp.color = TextColor;
        tmp.alpha = 1f;
        tmp.fontStyle = Config.TextFontStyle;
        tmp.fontWeight = Config.TextFontWeight;
        // Do not enable TMP auto-size globally. It causes labels to pulse between sizes when
        // a button refreshes. Individual style methods assign deterministic font sizes.
        tmp.enableAutoSizing = false;
        tmp.fontSize = ButtonFontSize;
        tmp.alignment = TextAlignmentOptions.Center;
        tmp.textWrappingMode = TextWrappingModes.NoWrap;
        tmp.overflowMode = TextOverflowModes.Overflow;
        tmp.richText = true;

        MeshRenderer renderer = tmp.GetComponent<MeshRenderer>();
        if (renderer != null)
        {
            renderer.enabled = true;
            renderer.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
            renderer.receiveShadows = false;
            renderer.sortingOrder = 100;
        }

        try
        {
            tmp.ForceMeshUpdate(true, true);
        }
        catch
        {
        }
    }

    private static Text FindLegacyText(GameObject root)
    {
        if (root == null)
            return null;

        Text own = root.GetComponent<Text>();
        if (own != null)
            return own;

        return root.GetComponentsInChildren<Text>(true).FirstOrDefault();
    }

    private static void SetText(GameObject root, string value)
    {
        if (root == null)
            return;

        TMP_Text tmp = EnsureTmpText(root);
        if (tmp != null)
        {
            tmp.text = value ?? string.Empty;
            tmp.color = TextColor;

            try
            {
                tmp.ForceMeshUpdate(true, true);
            }
            catch
            {
            }

            return;
        }

        Text legacy = FindLegacyText(root);
        if (legacy != null)
        {
            legacy.text = value ?? string.Empty;
            legacy.color = TextColor;
            legacy.resizeTextForBestFit = true;
            return;
        }

        TextMesh textMesh = root.GetComponent<TextMesh>() ?? root.GetComponentInChildren<TextMesh>(true);
        if (textMesh != null)
        {
            textMesh.text = value ?? string.Empty;
            textMesh.color = TextColor;
        }
    }

    private static void SetTextColor(GameObject root, Color color)
    {
        if (root == null)
            return;

        foreach (TMP_Text tmp in root.GetComponentsInChildren<TMP_Text>(true))
            tmp.color = color;

        foreach (Text text in root.GetComponentsInChildren<Text>(true))
            text.color = color;

        foreach (TextMesh textMesh in root.GetComponentsInChildren<TextMesh>(true))
            textMesh.color = color;
    }

    private static void SetButtonColor(GameObject button, Color color)
    {
        if (button == null)
            return;

        if (BackgroundRenderers.TryGetValue(button, out Renderer renderer) && renderer != null)
            ApplyRendererColor(renderer, color);
        else
            ApplyRendererColor(button.GetComponent<Renderer>(), color);
    }

    public static void ApplyRendererColor(Renderer renderer, Color color)
    {
        if (renderer == null)
            return;

        MaterialPropertyBlock block = new();
        renderer.GetPropertyBlock(block);
        block.SetColor("_Color", color);
        block.SetColor("_BaseColor", color);
        renderer.SetPropertyBlock(block);
    }

    private static void ApplyMaterialColor(Material material, Color color)
    {
        if (material == null)
            return;

        if (material.HasProperty("_Color"))
            material.SetColor("_Color", color);
        if (material.HasProperty("_BaseColor"))
            material.SetColor("_BaseColor", color);
    }

    public static (Vector3 position, Quaternion rotation, Vector3 up, Vector3 forward, Vector3 right) TrueLeftHand()
    {
        Quaternion rotation = GorillaTagger.Instance.leftHandTransform.rotation * GTPlayer.Instance.LeftHand.handRotOffset;
        Vector3 position = GorillaTagger.Instance.leftHandTransform.position +
                           GorillaTagger.Instance.leftHandTransform.rotation * GTPlayer.Instance.LeftHand.handOffset;

        return (position, rotation, rotation * Vector3.up, rotation * Vector3.forward, rotation * Vector3.right);
    }

    public static (Vector3 position, Quaternion rotation, Vector3 up, Vector3 forward, Vector3 right) TrueRightHand()
    {
        Quaternion rotation = GorillaTagger.Instance.rightHandTransform.rotation * GTPlayer.Instance.RightHand.handRotOffset;
        Vector3 position = GorillaTagger.Instance.rightHandTransform.position +
                           GorillaTagger.Instance.rightHandTransform.rotation * GTPlayer.Instance.RightHand.handOffset;

        return (position, rotation, rotation * Vector3.up, rotation * Vector3.forward, rotation * Vector3.right);
    }

    public static void WorldScale(GameObject obj, Vector3 targetWorldScale)
    {
        if (obj == null || obj.transform.parent == null)
            return;

        Vector3 parentScale = obj.transform.parent.lossyScale;
        obj.transform.localScale = new Vector3(
            targetWorldScale.x / Mathf.Max(0.0001f, parentScale.x),
            targetWorldScale.y / Mathf.Max(0.0001f, parentScale.y),
            targetWorldScale.z / Mathf.Max(0.0001f, parentScale.z));
    }

    public static void FixStickyColliders(GameObject platform)
    {
        if (platform == null)
            return;

        Vector3[] positions =
        {
            new(0f, 1f, 0f), new(0f, -1f, 0f),
            new(1f, 0f, 0f), new(-1f, 0f, 0f),
            new(0f, 0f, 1f), new(0f, 0f, -1f),
        };

        Quaternion[] rotations =
        {
            Quaternion.Euler(90f, 0f, 0f), Quaternion.Euler(-90f, 0f, 0f),
            Quaternion.Euler(0f, -90f, 0f), Quaternion.Euler(0f, 90f, 0f),
            Quaternion.identity, Quaternion.Euler(0f, 180f, 0f),
        };

        const float size = 0.025f;

        for (int i = 0; i < positions.Length; i++)
        {
            GameObject side = GameObject.CreatePrimitive(PrimitiveType.Cube);
            side.name = "ML_PlatformEdge";
            side.transform.SetParent(platform.transform, false);
            side.transform.localPosition = positions[i] * (size / 2f);
            side.transform.localRotation = rotations[i];
            WorldScale(side, new Vector3(size, size, 0.01f));

            Renderer renderer = side.GetComponent<Renderer>();
            if (renderer != null)
                renderer.enabled = false;
        }
    }

    private sealed class MenuSlot
    {
        public GameObject gameObject;
        public MenuPressButton press;
    }
}

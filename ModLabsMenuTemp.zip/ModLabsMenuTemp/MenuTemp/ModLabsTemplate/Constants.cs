namespace ModLabs;

public abstract class Constants
{
    public const string Guid = "modlabs.menu.template";
    public const string Name = Config.MenuName;
    public const string Description = Config.MenuName + "Developed by Meltixx";
    public const string Version = "1.5.0";
}
